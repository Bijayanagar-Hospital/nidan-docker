import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button, ModalBody, ModalFooter, ModalHeader } from '@carbon/react';
import styles from './paywall-block-modal.scss';

interface PaywallBlockModalProps {
  close(): void;
  patientUuid: string;
  workspaceName: string;
  reason: string;
  outstandingAmount?: number;
  currency?: string;
}

const PaywallBlockModal: React.FC<PaywallBlockModalProps> = ({
  close,
  reason,
  outstandingAmount,
  currency = 'NPR',
}) => {
  const { t } = useTranslation();

  const formattedAmount =
    typeof outstandingAmount === 'number'
      ? new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(outstandingAmount)
      : null;

  return (
    <>
      <ModalHeader closeModal={close} title={t('paymentRequired', 'Payment Required')} />
      <ModalBody>
        <div className={styles.modalContent}>
          <div className={styles.iconContainer}>
            <svg
              width="64"
              height="64"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </div>

          <h2 className={styles.title}>{t('actionBlocked', 'Action Blocked')}</h2>

          <p className={styles.reason}>{reason}</p>

          {formattedAmount && (
            <div className={styles.amountCard}>
              <div className={styles.amountLabel}>{t('outstandingBalance', 'Outstanding Balance')}</div>
              <div className={styles.amountValue}>{formattedAmount}</div>
            </div>
          )}

          <div className={styles.infoMessage}>
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="16" x2="12" y2="12" />
              <line x1="12" y1="8" x2="12.01" y2="8" />
            </svg>
            <span>
              {t(
                'paywallInstruction',
                'Please direct the patient to the billing counter to clear outstanding dues before launching this workspace.',
              )}
            </span>
          </div>
        </div>
      </ModalBody>
    </>
  );
};

export default PaywallBlockModal;
