import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

export interface PaywallConfig {
  enabled: boolean;
  scope: 'visit_ticket' | 'full';
  override: 'clinical' | 'none';
  insuranceBypass: boolean;
  outageMode: 'allow' | 'deny';
  canSkip: boolean;
  effectiveEnforcing: boolean;
  gatedActions: string[];
  messages: {
    block: string;
    warn: string;
    outage: string;
    skip: string;
  };
}

export interface PaywallCheckResponse {
  decision: 'allow' | 'warn' | 'block';
  blocked: boolean;
  mode: string;
  dueAmount: number;
  cartAmount: number;
  outstandingAmount: number;
  currency: string;
  scope: string;
  paymentStatus: string;
  reason?: string;
  patientUuid: string;
  visitUuid?: string;
}

let cachedConfigPromise: Promise<PaywallConfig> | null = null;

export function getPaywallConfig(): Promise<PaywallConfig> {
  if (!cachedConfigPromise) {
    cachedConfigPromise = openmrsFetch('/ws/rest/v1/nidan/paywall/frontend-config')
      .then((res) => res.data as PaywallConfig)
      .catch((err) => {
        console.error('Failed to fetch paywall frontend-config:', err);
        // Revert to a default safe (non-blocking) configuration if fetch fails
        return {
          enabled: false,
          scope: 'full',
          override: 'none',
          insuranceBypass: false,
          outageMode: 'allow',
          canSkip: false,
          effectiveEnforcing: false,
          gatedActions: [],
          messages: {
            block: 'Payment required before proceeding.',
            warn: 'Outstanding payment — care continues; please settle at billing.',
            outage: 'Billing system unreachable — proceed and revert to physical billing.',
            skip: 'Emergency Payment Skip active — care not blocked.',
          },
        };
      });
  }
  return cachedConfigPromise;
}

export function resetPaywallConfigCache() {
  cachedConfigPromise = null;
}

// ---------------------------------------------------------------------------
// Per-patient payment status cache
// Shared between the banner tag (React) and the gatekeeper (plain TS) so that
// opening a gated workspace on a patient page that already loaded the tag does
// NOT fire a second network request within the TTL window.
// ---------------------------------------------------------------------------

const DEFAULT_PAYMENT_STATUS_TTL_MS = 30_000; // overridden by config cacheTtlMs

interface CacheEntry {
  result: PaywallCheckResponse;
  expiresAt: number;
}

const paymentStatusCache = new Map<string, CacheEntry>();

function buildCacheKey(patientUuid: string, visitUuid?: string, orderType?: string, checkTicket?: boolean): string {
  return [patientUuid, visitUuid ?? '', orderType ?? '', String(checkTicket ?? false)].join('|');
}

/** Force-invalidate a cached entry (e.g. after a successful payment). */
export function invalidatePaymentStatusCache(patientUuid: string, visitUuid?: string): void {
  // Remove all entries whose key starts with this patient/visit combo
  for (const key of paymentStatusCache.keys()) {
    if (key.startsWith(`${patientUuid}|${visitUuid ?? ''}`)) {
      paymentStatusCache.delete(key);
    }
  }
}

export async function checkPaymentStatus(
  patientUuid: string,
  visitUuid?: string,
  orderType?: string,
  checkTicket?: boolean,
  ttlMs: number = DEFAULT_PAYMENT_STATUS_TTL_MS,
): Promise<PaywallCheckResponse> {
  const cacheKey = buildCacheKey(patientUuid, visitUuid, orderType, checkTicket);
  const cached = paymentStatusCache.get(cacheKey);

  if (cached && Date.now() < cached.expiresAt) {
    return cached.result;
  }

  const params = new URLSearchParams({ patientUuid });
  if (visitUuid) params.append('visitUuid', visitUuid);
  if (orderType) params.append('orderType', orderType);
  if (checkTicket) params.append('checkTicket', checkTicket.toString());

  const res = await openmrsFetch(`${restBaseUrl}/nidan/paywall/check?${params.toString()}`);
  const result = res.data as PaywallCheckResponse;

  paymentStatusCache.set(cacheKey, { result, expiresAt: Date.now() + ttlMs });

  return result;
}

// ---------------------------------------------------------------------------
// IPD bed-assignment check
// Used by the gatekeeper to detect inpatients. For IPD patients, only the
// workspaces listed in ipdOnlyBlockWorkspaces (e.g. patient-discharge-workspace)
// are payment-gated; all other gated workspaces are skipped.
// Cache TTL is long (5 min) because bed assignments change rarely.
// ---------------------------------------------------------------------------

const BED_CACHE_TTL_MS = 5 * 60_000; // 5 minutes

interface BedCacheEntry {
  hasBed: boolean;
  expiresAt: number;
}

const bedCache = new Map<string, BedCacheEntry>();

/** Returns true if the patient is currently assigned to a bed (i.e. is an IPD inpatient). */
export async function checkPatientHasBed(patientUuid: string): Promise<boolean> {
  const cached = bedCache.get(patientUuid);
  if (cached && Date.now() < cached.expiresAt) {
    return cached.hasBed;
  }

  try {
    const res = await openmrsFetch(`${restBaseUrl}/beds?patientUuid=${patientUuid}`);
    const beds: unknown[] = Array.isArray(res.data?.results) ? res.data.results : [];
    const hasBed = beds.length > 0;
    bedCache.set(patientUuid, { hasBed, expiresAt: Date.now() + BED_CACHE_TTL_MS });
    return hasBed;
  } catch (err) {
    // Fail-open: if the bed API is unreachable, assume OPD (no bypass)
    console.warn('Could not determine bed assignment for patient', patientUuid, err);
    return false;
  }
}

/** Evict a patient's bed-cache entry (e.g. after discharge). */
export function invalidateBedCache(patientUuid: string): void {
  bedCache.delete(patientUuid);
}
