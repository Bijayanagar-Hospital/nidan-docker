import { Type } from '@openmrs/esm-framework';

export const paywallGatekeeperConfigSchema = {
  pollingIntervalMs: {
    _type: Type.Number,
    _default: 60_000,
    _description: 'How often (milliseconds) the payment-status banner tag re-polls the /check endpoint while the patient chart is open.',
  },
  cacheTtlMs: {
    _type: Type.Number,
    _default: 30_000,
    _description: 'How long (milliseconds) a /check response is reused from the in-memory cache before a fresh network request is made.',
  },
  ipdOnlyBlockWorkspaces: {
    _type: Type.Array,
    _elements: { _type: Type.String },
    _default: ['patient-discharge-workspace'],
    _description:
      'Workspaces that are still payment-gated even when the patient is an IPD (bed-assigned) inpatient. All other gated workspaces are skipped for IPD patients.',
  },
  gatedWorkspaces: {
    _type: Type.Array,
    _elements: {
      _type: Type.Object,
      workspaceName: {
        _type: Type.String,
        _description: 'The distinct identifier name of the O3 workspace to gate (e.g., add-drug-order).',
      },
      patientUuidKey: {
        _type: Type.String,
        _default: 'patientUuid',
        _description: 'The property key within the workspace context that holds the patient UUID string value.',
      },
      orderType: {
        _type: Type.String,
        _default: '',
        _description: 'Optional: Filter rule by specific order type category (e.g., DRUG, TEST, LAB) sent to checkPaymentStatus.',
      },
      checkTicket: {
        _type: Type.Boolean,
        _default: false,
        _description: 'Optional: If true, tells the billing backend to specifically validate visit/consultation tickets.',
      },
    },
    _description: 'A dynamic list of OpenMRS workspaces restricted by the billing paywall gatekeeper module with specific filter criteria.',
    _default: [
      {
        workspaceName: 'patient-discharge-workspace',
        patientUuidKey: 'patientUuid',
        orderType: '',
        checkTicket: false
      },
      {
        workspaceName: 'patient-form-entry-workspace',
        patientUuidKey: 'patientUuid',
        orderType: '',
        checkTicket: false
      },
      {
        workspaceName: 'add-drug-order',
        patientUuidKey: 'patientUuid',
        checkTicket: false
      },
      {
        workspaceName: 'add-lab-order',
        patientUuidKey: 'patientUuid',
        checkTicket: false
      },
      {
        workspaceName: 'add-procedures-order',
        patientUuidKey: 'patientUuid',
        checkTicket: false
      },
      {
        workspaceName: 'add-medical-supply-order',
        patientUuidKey: 'patientUuid',
        checkTicket: false
      },
      {
        workspaceName: 'add-imaging-order-workspace',
        patientUuidKey: 'patientUuid',
        checkTicket: false
      },
      {
        workspaceName: 'order-basket',
        patientUuidKey: 'patientUuid',
        checkTicket: false
      },
      {
        workspaceName: 'test-results-form-workspace',
        patientUuidKey: 'patientUuid',
        orderType: 'lab',
        checkTicket: false
      },
      {
        workspaceName: 'lab-app-test-results-form-workspace',
        patientUuidKey: 'patientUuid',
        orderType: 'lab',
        checkTicket: false
      },
      {
        workspaceName: 'radiology-report-form-workspace',
        patientUuidKey: 'patientUuid',
        orderType: 'radiology',
        checkTicket: false
      },
      {
        workspaceName: 'procedure-report-form-workspace',
        patientUuidKey: 'patientUuid',
        orderType: 'procedure',
        checkTicket: false
      }
    ],
  },
};

export interface PaywallGatekeeperConfig {
  pollingIntervalMs: number;
  cacheTtlMs: number;
  ipdOnlyBlockWorkspaces: string[];
  gatedWorkspaces: Array<{
    workspaceName: string;
    patientUuidKey: string;
    orderType?: string;
    checkTicket?: boolean;
  }>;
}