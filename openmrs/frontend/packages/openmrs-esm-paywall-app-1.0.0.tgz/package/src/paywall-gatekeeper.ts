import { workspace2Store, workspace2StoreActions } from '@openmrs/esm-framework/src/internal';
import { getConfig, showModal, showSnackbar } from '@openmrs/esm-framework';
import { getPaywallConfig, checkPaymentStatus, checkPatientHasBed } from './paywall.resource';
import { moduleName } from './constants';
import type { PaywallGatekeeperConfig } from './config-schema';

export function initializeWorkspaceGatekeeper() {
  let previousOpenedWindows: any[] = [];

  workspace2Store.subscribe(async (state) => {
    const { openedWindows, openedGroup } = state;

    // Detect if any new workspace was added
    const newlyOpenedWorkspace = findNewlyOpenedWorkspace(openedWindows, previousOpenedWindows);
    previousOpenedWindows = openedWindows;

    if (!newlyOpenedWorkspace) return;

    const workspaceName = newlyOpenedWorkspace.workspaceName;

    try {
      // ── Fast path ────────────────────────────────────────────────────────
      // getPaywallConfig() is a cached promise (one network fetch per session).
      // effectiveEnforcing = enabled AND NOT canSkip — the single correct gate
      // per the API spec. When false, bail out before any further work.
      const paywallConfig = await getPaywallConfig();
      if (!paywallConfig.effectiveEnforcing) return;

      // ── Workspace gate lookup ─────────────────────────────────────────────
      // Load the configurable gated workspace list and build a keyed lookup.
      const { gatedWorkspaces, ipdOnlyBlockWorkspaces, cacheTtlMs } =
        await getConfig<PaywallGatekeeperConfig>(moduleName);
      const gatedWorkspaceMap = Object.fromEntries(gatedWorkspaces.map((entry) => [entry.workspaceName, entry]));

      const gatingConfig = gatedWorkspaceMap[workspaceName];
      if (!gatingConfig) return;

      const patientUuidKey = gatingConfig.patientUuidKey ?? 'patientUuid';

      // Extract the patient UUID and visit UUID from props or group context
      const patientUuid =
        newlyOpenedWorkspace.props?.[patientUuidKey] ||
        newlyOpenedWorkspace.props?.patient?.uuid ||
        newlyOpenedWorkspace.props?.patientUuid ||
        openedGroup?.props?.patientUuid ||
        openedGroup?.props?.patient?.uuid ||
        openedGroup?.props?.wardPatient?.patient?.uuid;

      const visitUuid =
        newlyOpenedWorkspace.props?.visitUuid ||
        newlyOpenedWorkspace.props?.visitContext?.uuid ||
        openedGroup?.props?.visitUuid ||
        openedGroup?.props?.wardPatient?.visit?.uuid ||
        openedGroup?.props?.visit?.uuid ||
        openedGroup?.props?.visitContext?.uuid;

      if (!patientUuid) {
        console.warn(`Gated workspace "${workspaceName}" launched without a patientUuid.`);
        return;
      }

      // ── IPD bypass ───────────────────────────────────────────────────────
      // If the patient is assigned to a bed (inpatient), only gate the workspaces
      // explicitly listed in ipdOnlyBlockWorkspaces (e.g. discharge). All other
      // gated workspaces are skipped so clinical care is never blocked mid-admission.
      const hasBed = await checkPatientHasBed(patientUuid);
      if (hasBed && !ipdOnlyBlockWorkspaces.includes(workspaceName)) return;

      // ── Payment check ─────────────────────────────────────────────────────
      // Forward per-workspace filter options (orderType, checkTicket) from config.
      // Result is served from the shared in-memory cache (TTL = cacheTtlMs).
      const checkResult = await checkPaymentStatus(
        patientUuid,
        visitUuid,
        gatingConfig.orderType || undefined,
        gatingConfig.checkTicket ?? false,
        cacheTtlMs,
      );

      if (checkResult.decision === 'block') {
        // Immediately revert state (close the workspace) to prevent mounting/flickering
        workspace2Store.setState(workspace2StoreActions.closeWorkspace(workspace2Store.getState(), workspaceName));

        showModal('paywall-block-modal', {
          patientUuid,
          workspaceName,
          reason: checkResult.reason || 'Payment required before launching this workspace.',
          outstandingAmount: checkResult.outstandingAmount,
          currency: checkResult.currency || '',
        });
      } else if (checkResult.decision === 'warn') {
        showSnackbar({
          title: 'Outstanding Dues',
          subtitle: checkResult.reason || 'This patient has pending billing dues.',
          kind: 'warning',
          autoClose: false,
        });
      }
    } catch (error) {
      console.error(`Failed to verify payment status for workspace "${workspaceName}":`, error);
      // Fail-open: never block a clinical workspace due to a billing infrastructure error
    }
  });
}

function findNewlyOpenedWorkspace(currentWindows: any[], previousWindows: any[]) {
  const currentWorkspaces = currentWindows.flatMap((w) => w.openedWorkspaces || []);
  const previousWorkspaces = previousWindows.flatMap((w) => w.openedWorkspaces || []);

  // Return the first workspace in current that wasn't in previous
  return currentWorkspaces.find(
    (curr) => !previousWorkspaces.some((prev) => prev.workspaceName === curr.workspaceName),
  );
}
