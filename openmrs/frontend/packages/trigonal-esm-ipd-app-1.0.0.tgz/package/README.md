# trigonal-esm-ipd-app

An [OpenMRS 3.0](https://o3-docs.openmrs.org) microfrontend module for **In-Patient Department (IPD)** management. Built with React, Carbon Design System, and the OpenMRS ESM (Extension System Module) pattern.

> 👋 New to OpenMRS frontend development? Start with the [O3 Frontend Developer Documentation](https://o3-docs.openmrs.org) and the [Map of the Project](https://o3-docs.openmrs.org/docs/frontend-modules/overview).

---

## Modules

This repository contains a single ESM app with the following features:

| Feature | Description |
|---|---|
| **Care View Dashboard** | Ward-level IPD overview — lists all admitted patients with bed assignments and quick actions. Accessible from the main homepage. |
| **Patient IPD Dashboard** | Per-patient IPD view inside the O3 patient chart. Shows bed assignment banner, nursing tasks, drug/medication chart, vitals, and allergies. |
| **Bed Assignment Banner** | Inline banner showing the patient's current bed and ward within the patient chart. |
| **Nursing Task Form** | Workspace for creating and editing nursing care tasks (IV, O2, wound care, etc.). |
| **Drug Chart** | Medication schedule chart for tracking administration over time. |
| **Vitals** | IPD-contextualised vitals panel for the active visit. |
| **Allergies** | Read-only allergy summary surfaced within the IPD view. |

### Entry points

| Route | Component | Slot |
|---|---|---|
| `/home/ipd` | `CareViewDashboard` | Page (full view) |
| Patient chart left nav | `PatientIpdLink` | `patient-chart-dashboard-slot` |
| Patient chart `/chart/ipd-summary` | `PatientIpdDashboard` | `patient-ipd-slot` |

---

## Setup

### Prerequisites

- [Node.js](https://nodejs.org) ≥ 18
- [Yarn](https://yarnpkg.com) 4.x (managed via `packageManager` in `package.json`)

### Install dependencies

```sh
yarn install
```

### Configure environment

Copy the example environment file and fill in the required values:

```sh
cp .env.example .env
```

> The `.env` file is used only for E2E tests. For local development the app proxies to a remote backend specified via `--backend`.

---

## Development

Start a local dev server proxied against the OpenMRS reference application backend:

```sh
yarn start --backend https://dev3.openmrs.org/
```

Start on a specific port (default is auto-assigned):

```sh
yarn start --backend https://dev3.openmrs.org/ --port 3000
```

The SPA will be available at **`http://localhost:3000/openmrs/spa`**.

To point at a local backend instead:

```sh
yarn start --backend http://localhost:8080/
```

---

## Building

```sh
yarn build
```

The compiled bundle is written to `dist/trigonal-esm-ipd-app.js`.

To analyse the bundle size:

```sh
yarn analyze
```

---

## Running tests

### Unit tests

```sh
yarn test
```

To run tests in watch mode:

```sh
yarn test --watch
```

To generate a coverage report:

```sh
yarn coverage
```

### E2E tests

1. Install Playwright browsers (first time only):

```sh
npx playwright install
```

2. Start the dev server in one terminal:

```sh
yarn start --backend https://dev3.openmrs.org/
```

3. In a separate terminal, run the E2E suite:

```sh
yarn test-e2e --headed
```

---

## Linting & formatting

```sh
yarn lint       # ESLint — zero warnings policy
yarn prettier   # Prettier auto-format
yarn typescript # Type-check only (no emit)
```

---

## i18n / Translations

Translation keys are extracted automatically from component source files:

```sh
yarn extract-translations
```

Translation files live in `translations/`. The following locales are included out of the box:

| Locale | File |
|---|---|
| English | `translations/en.json` |
| Spanish | `translations/es.json` |
| French | `translations/fr.json` |
| Arabic (RTL) | `translations/ar.json` |

To add a new locale, add the corresponding JSON file to `translations/` and register it in `src/index.ts` via the `importTranslation` context.

---

## Configuration

This module is fully driven by the OpenMRS configuration framework. Configuration is defined in `src/config-schema.ts`.

Key configuration options:

| Key | Default | Description |
|---|---|---|
| `ipdDashboardSections` | See schema | Ordered list of sections to show in the patient IPD dashboard |
| `showNursingTasks` | `true` | Toggle the Nursing Tasks section |
| `showMedicationChart` | `true` | Toggle the Drug/Medication Chart section |
| `patientSearchMinChars` | `3` | Minimum characters before triggering patient search in Care View |

To customise via the O3 config UI, navigate to the **System Administration → Manage Frontend Configuration** page.

---

## Project structure

```
src/
├── features/
│   ├── allergies/            # Allergy summary panel
│   ├── bed-assignment/       # Bed assignment banner
│   ├── care-view/            # Ward-level dashboard
│   ├── drug-chart/           # Medication schedule chart
│   ├── nursing-tasks/        # Nursing task list + form workspace
│   ├── patient-ipd/          # Per-patient IPD dashboard
│   └── vitals/               # Vitals panel
├── utils/                    # Shared utilities (audit events, RTL helpers)
├── types/                    # Shared TypeScript types
├── config-schema.ts          # Module configuration schema
├── constants.ts              # Shared constants
├── index.ts                  # ESM entry point — registers pages, extensions, workspaces
├── routes.json               # O3 routes / extension slot declarations
├── root.component.tsx        # BrowserRouter root for /home/ipd
├── ipd-dashboard-link.component.tsx   # Homepage nav link → /home/ipd
└── patient-ipd-link.component.tsx     # Patient chart nav link → /chart/ipd-summary
translations/
├── en.json
├── es.json
├── fr.json
└── ar.json
```

---

## Backend dependencies

| Module | Minimum version |
|---|---|
| `webservices.rest` | `^2.24.0` |
| `fhir2` | `≥1.2` |
| `bedmanagement` | `≥5.0` |

---

## Contributing

Please read the [OpenMRS Contributing Guide](https://wiki.openmrs.org/display/docs/Contributing+Code) before opening a pull request.

- Fork the repository and create a feature branch from `main`.
- Ensure `yarn lint` and `yarn test` both pass before submitting.
- Reference the related Jira ticket or GitHub issue in your PR description.
- Keep PRs focused — one feature or fix per pull request.

---

## Versioning & release

To increment the version:

```sh
yarn version patch   # or minor / major
```

After merging the version bump to `main`, [draft a new GitHub release](https://github.com/releases/new). The tag should be prefixed with `v` (e.g. `v1.1.0`). Creating the release will trigger the GitHub Actions publish workflow.

> Do **not** run `npm publish` or `yarn publish` directly.

---

## License

[MPL-2.0](./LICENSE) — Mozilla Public License 2.0

---

## Links

- [OpenMRS O3 Docs](https://o3-docs.openmrs.org)
- [Carbon Design System](https://carbondesignsystem.com)
- [OpenMRS Talk (Community Forum)](https://talk.openmrs.org)
- [OpenMRS JIRA](https://issues.openmrs.org)
