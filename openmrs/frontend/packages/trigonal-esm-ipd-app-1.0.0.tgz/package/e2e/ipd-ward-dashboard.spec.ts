import { expect, test } from '@playwright/test';

/**
 * IPD-07 — E2E test suite
 *
 * Covers the full user flow:
 *   1. Navigate to /home/ipd (ward dashboard)
 *   2. Ward chips are rendered
 *   3. Select a ward → summary tiles appear
 *   4. Patient table populates
 *   5. "View IPD" button navigates to the patient IPD dashboard
 *   6. Patient IPD dashboard sections render (Allergies, Nursing Tasks, Drug Chart)
 *   7. "Add Task" opens the add-task workspace
 *   8. Bed assignment banner is visible
 *
 * Prerequisites:
 *   - E2E_BASE_URL → running O3 instance with the @trigonal/esm-ipd-app deployed
 *   - E2E_USER_ADMIN_USERNAME / E2E_USER_ADMIN_PASSWORD
 *   - At least one ward with admitted patients in the test DB
 *   - Environment variables set in .env (copy example.env)
 */

const SPA_BASE = process.env.E2E_BASE_URL + '/spa';

test.describe('IPD Ward Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(`${SPA_BASE}/home/ipd`);
  });

  test('renders the IPD page with ward chips', async ({ page }) => {
    await expect(page.getByText('Select Ward')).toBeVisible();
    // At least one ward chip must be present
    const wardChips = page.locator('.cds--tag');
    await expect(wardChips.first()).toBeVisible();
  });

  test('shows summary tiles after ward selection', async ({ page }) => {
    // Click the first ward chip
    const firstWard = page.locator('.cds--tag').first();
    await firstWard.click();

    await expect(page.getByText('Total Patients')).toBeVisible({ timeout: 10_000 });
    await expect(page.getByText('My Patients')).toBeVisible();
  });

  test('populates the patient table after ward selection', async ({ page }) => {
    const firstWard = page.locator('.cds--tag').first();
    await firstWard.click();

    // Wait for the DataTable to render at least one row
    const tableRows = page.locator('.cds--data-table tbody tr');
    await expect(tableRows.first()).toBeVisible({ timeout: 15_000 });
  });

  test('patient search filters the table', async ({ page }) => {
    const firstWard = page.locator('.cds--tag').first();
    await firstWard.click();

    // Wait for the search input
    const searchInput = page.getByRole('searchbox');
    await expect(searchInput).toBeVisible({ timeout: 10_000 });

    // Type fewer than 3 chars — table should NOT re-query
    await searchInput.fill('AB');
    // Table should still show previous results (not cleared)
    await expect(page.locator('.cds--data-table tbody tr').first()).toBeVisible();

    // Type 3+ chars — query fires
    await searchInput.fill('ABU');
    // May return 0 or more rows; just ensure no crash
    await page.waitForTimeout(500);
    const noMatchText = page.getByText('No results found');
    // either rows are present or the empty state renders
    const hasRows = await page.locator('.cds--data-table tbody tr').count();
    expect(hasRows >= 0).toBeTruthy();
  });

  test('"View IPD" button navigates to patient IPD chart', async ({ page }) => {
    const firstWard = page.locator('.cds--tag').first();
    await firstWard.click();

    // Wait for patient table
    const firstViewIpdBtn = page.getByRole('link', { name: 'View IPD' }).first();
    await expect(firstViewIpdBtn).toBeVisible({ timeout: 15_000 });

    const href = await firstViewIpdBtn.getAttribute('href');
    expect(href).toContain('/patient/');
    expect(href).toContain('/chart/ipd-summary');
  });
});

test.describe('IPD Patient Dashboard', () => {
  /**
   * Navigates directly to a known patient's IPD summary page.
   * The patient UUID is taken from E2E_TEST_PATIENT_UUID env var.
   */
  const patientUuid = process.env.E2E_TEST_PATIENT_UUID ?? 'PLACEHOLDER_UUID';

  test.beforeEach(async ({ page }) => {
    await page.goto(`${SPA_BASE}/patient/${patientUuid}/chart/ipd-summary`);
  });

  test('renders the bed assignment banner', async ({ page }) => {
    // Either "Current Bed" or "No bed assigned" must be present
    const banner = page.locator('.cds--tile').first();
    await expect(banner).toBeVisible({ timeout: 10_000 });

    const hasBed = await page.getByText('Current Bed').isVisible().catch(() => false);
    const noBed = await page.getByText('No bed assigned').isVisible().catch(() => false);
    expect(hasBed || noBed).toBeTruthy();
  });

  test('renders Allergies accordion section', async ({ page }) => {
    await expect(page.getByText('Allergies')).toBeVisible({ timeout: 10_000 });
  });

  test('renders Nursing Tasks accordion section', async ({ page }) => {
    await expect(page.getByText('Nursing Tasks')).toBeVisible({ timeout: 10_000 });
  });

  test('renders Drug Chart accordion section', async ({ page }) => {
    await expect(page.getByText('Drug Chart')).toBeVisible({ timeout: 10_000 });
  });

  test('"Assign Bed" button opens the bed assignment workspace', async ({ page }) => {
    const assignBtn = page.getByRole('button', { name: /assign bed/i });
    await expect(assignBtn).toBeVisible({ timeout: 10_000 });
    await assignBtn.click();

    // The O3 workspace panel slides in from the right
    await expect(page.locator('.omrs-workspace-container')).toBeVisible({ timeout: 5_000 });
  });

  test('"Add Task" button opens the nursing task workspace', async ({ page }) => {
    const addTaskBtn = page.getByRole('button', { name: 'Add Task' });
    await expect(addTaskBtn).toBeVisible({ timeout: 10_000 });
    await addTaskBtn.click();

    await expect(page.locator('.omrs-workspace-container')).toBeVisible({ timeout: 5_000 });
    await expect(page.getByLabel('Task Name')).toBeVisible();
  });

  test('nursing task form validates minimum name length', async ({ page }) => {
    const addTaskBtn = page.getByRole('button', { name: 'Add Task' });
    await addTaskBtn.click();

    const taskNameInput = page.getByLabel('Task Name');
    await taskNameInput.fill('AB');
    await page.getByRole('button', { name: 'Save Task' }).click();

    await expect(
      page.getByText('Task name must be at least 3 characters'),
    ).toBeVisible({ timeout: 3_000 });
  });

  test('drug chart date navigator moves between days', async ({ page }) => {
    // Make sure Drug Chart section is open
    const drugChartHeader = page.getByText('Drug Chart');
    await drugChartHeader.click();

    const prevDayBtn = page.getByRole('button', { name: 'Previous day' });
    await expect(prevDayBtn).toBeVisible({ timeout: 10_000 });

    const dateLabelBefore = await page.locator('[class*="dateLabel"]').innerText();
    await prevDayBtn.click();
    const dateLabelAfter = await page.locator('[class*="dateLabel"]').innerText();

    expect(dateLabelBefore).not.toBe(dateLabelAfter);
  });

  test('"Add Medication" button opens the add-medication workspace', async ({ page }) => {
    const addMedBtn = page.getByRole('button', { name: 'Add Medication' });
    await expect(addMedBtn).toBeVisible({ timeout: 10_000 });
    await addMedBtn.click();

    await expect(page.locator('.omrs-workspace-container')).toBeVisible({ timeout: 5_000 });
  });
});
