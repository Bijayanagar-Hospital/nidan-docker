import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import last from 'lodash-es/last';
import { BrowserRouter, useLocation } from 'react-router-dom';
import { ConfigurableLink } from '@openmrs/esm-framework';

interface IpdLinkConfig {
  name: string;
  title: string;
}

/**
 * Factory that returns a React component pre-configured with the given link name/title.
 * Follows the same pattern as createLeftPanelLink in the imaging-orders app.
 */
export const createIpdDashboardLink = (config: IpdLinkConfig) => () => {
  return (
    <BrowserRouter>
      <IpdDashboardLinkExtension config={config} />
    </BrowserRouter>
  );
};

function IpdDashboardLinkExtension({ config }: { config: IpdLinkConfig }) {
  const { t } = useTranslation();
  const { name, title } = config;
  const location = useLocation();
  const spaBasePath = `${window.getOpenmrsSpaBase()}home`;

  const urlSegment = useMemo(
    () => decodeURIComponent(last(location.pathname.split('/')) ?? ''),
    [location.pathname],
  );

  return (
    <ConfigurableLink
      to={`${spaBasePath}/${name}`}
      className={`cds--side-nav__link ${name === urlSegment ? 'active-left-nav-link' : ''}`}
    >
      {t('ipd', title)}
    </ConfigurableLink>
  );
}
