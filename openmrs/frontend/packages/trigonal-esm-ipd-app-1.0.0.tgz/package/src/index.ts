import { defineConfigSchema, getSyncLifecycle } from '@openmrs/esm-framework';
import { moduleName } from './constants';
import { configSchema } from './config-schema';
import Root from './root.component';
import { createIpdDashboardLink } from './ipd-dashboard-link.component';
import { createPatientIpdLink } from './patient-ipd-link.component';
import PatientIpdDashboard from './features/patient-ipd/patient-ipd-dashboard.component';
import BedAssignmentBanner from './features/bed-assignment/bed-assignment-banner.component';
import NursingTaskFormWorkspace from './features/nursing-tasks/nursing-task-form.workspace';

const options = {
  featureName: 'esm-ipd-app',
  moduleName,
};

/**
 * Lazy-load translation bundles from the /translations directory.
 * The `lazy` webpack magic comment keeps each locale as a separate chunk.
 */
export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

// ── Pages ────────────────────────────────────────────────────────────────────

/**
 * root — the full-page ward/care-view dashboard mounted at /home/ipd
 * Registered as a `page` in routes.json.
 */
export const root = getSyncLifecycle(Root, options);

// ── Homepage extensions ──────────────────────────────────────────────────────

/**
 * ipdDashboardLink — appears in the main homepage left-panel navigation.
 * Clicking navigates to /home/ipd (the ward-level care view dashboard).
 * Slot: homepage-dashboard-slot
 */
export const ipdDashboardLink = getSyncLifecycle(
  createIpdDashboardLink({ name: 'ipd', title: 'IPD' }),
  options,
);

// ── Patient chart extensions ─────────────────────────────────────────────────

/**
 * patientIpdLink — appears in every patient chart's left-panel navigation.
 * Clicking navigates to /patient/{uuid}/chart/ipd-summary.
 * Slot: patient-chart-dashboard-slot
 */
export const patientIpdLink = getSyncLifecycle(
  createPatientIpdLink({ title: 'IPD Summary' }),
  options,
);

/**
 * patientIpdDashboard — the full patient IPD view (medications, nursing tasks,
 * drug chart, allergies, vitals, etc.) rendered inside the patient chart.
 * Slot: patient-ipd-slot
 */
export const patientIpdDashboard = getSyncLifecycle(PatientIpdDashboard, options);

/**
 * bedAssignmentBanner — IPD-05
 * Displayed at the top of the patient IPD view.
 * Slot: patient-ipd-banner-slot
 */
export const bedAssignmentBanner = getSyncLifecycle(BedAssignmentBanner, options);

// ── Workspaces ───────────────────────────────────────────────────────────────

/**
 * addIpdTaskWorkspace — IPD-02
 * Opened via launchWorkspace('add-ipd-task', { patientUuid, visitUuid, mutateTaskList }).
 */
export const addIpdTaskWorkspace = getSyncLifecycle(NursingTaskFormWorkspace, options);
