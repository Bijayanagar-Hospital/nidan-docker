import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { WorkspaceContainer, attach, ExtensionSlot } from '@openmrs/esm-framework';
import CareViewDashboard from './features/care-view/care-view-dashboard.component';
import { useSession } from '@openmrs/esm-framework';

/**
 * Root component — mounted as a full SPA page at /home/ipd.
 *
 * Migration note: The legacy app used a Webpack Module Federation remote entry
 * (remoteEntry.js) and exposed CareViewDashboard via a module federation
 * container. In O3, getSyncLifecycle() handles lifecycle and routing is
 * done via react-router inside a BrowserRouter with the O3 spa base path.
 *
 * Route path="/*" (not "/") is required because when the browser URL equals
 * the BrowserRouter basename exactly (e.g. /openmrs/spa/home/ipd), React
 * Router v6 <Routes> sees an empty remaining path ("") rather than "/" and
 * a plain path="/" would not match, rendering nothing.
 */

attach('ipd-dashboard-ward-slot', 'ward-view');
const Root: React.FC = () => {
  const baseName = window.getOpenmrsSpaBase() + 'home/ipd';
  const session = useSession();

console.log('roles', session.user?.roles);

  return (
    // <BrowserRouter basename={baseName}>
    //   <Routes>
    //     {/* <Route path="/*" element={<CareViewDashboard />} /> */}
    //   </Routes>
    //   {/* <WorkspaceContainer contextKey="ipd" /> */}
    // </BrowserRouter>
    <div>
      <ExtensionSlot name="ipd-dashboard-ward-slot" />
    </div>
  );
};

export default Root;
