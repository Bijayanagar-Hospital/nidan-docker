/**
 * Module augmentation file for @carbon/react.
 *
 * Carbon v1.102+ ships component JS without co-located .d.ts files
 * (e.g. OverflowMenu, IconButton). These shims add the missing exports
 * so TypeScript resolves them correctly.
 *
 * `export {}` makes this a module file so `declare module` below is an
 * *augmentation* that ADDS to existing Carbon types rather than replacing them.
 */
export {};

declare module '@carbon/react' {
  import type React from 'react';

  export interface OverflowMenuProps extends React.HTMLAttributes<HTMLElement> {
    size?: 'sm' | 'md' | 'lg';
    flipped?: boolean;
    selectorPrimaryFocus?: string;
    iconDescription?: string;
    renderIcon?: React.ComponentType;
    children?: React.ReactNode;
    className?: string;
    id?: string;
    open?: boolean;
    onOpen?: () => void;
    onClose?: () => void;
    focusTrap?: boolean;
    menuOptionsClass?: string;
    innerRef?: React.Ref<HTMLElement>;
  }

  export interface OverflowMenuItemProps extends React.LiHTMLAttributes<HTMLLIElement> {
    children?: React.ReactNode;
    className?: string;
    disabled?: boolean;
    hasDivider?: boolean;
    isDelete?: boolean;
    itemText?: React.ReactNode;
    onClick?: React.MouseEventHandler<HTMLButtonElement>;
    requireTitle?: boolean;
    title?: string;
    wrapperClassName?: string;
  }

  export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    children?: React.ReactNode;
    className?: string;
    disabled?: boolean;
    enterDelayMs?: number;
    kind?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'tertiary';
    label: string;
    leaveDelayMs?: number;
    renderIcon?: React.ComponentType;
    size?: 'sm' | 'md' | 'lg';
    tooltipAlignment?: 'start' | 'center' | 'end';
    tooltipPosition?: 'top' | 'bottom' | 'left' | 'right';
  }

  export const OverflowMenu: React.FC<OverflowMenuProps>;
  export const OverflowMenuItem: React.FC<OverflowMenuItemProps>;
  export const IconButton: React.FC<IconButtonProps>;
}
