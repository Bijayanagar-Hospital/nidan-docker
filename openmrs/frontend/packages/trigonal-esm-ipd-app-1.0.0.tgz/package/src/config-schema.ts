import { Type } from '@openmrs/esm-framework';
import type { DashboardSection } from './types';

/**
 * Module config schema — all values are overridable via the O3 Implementer Tools.
 *
 * UUIDs here are OpenMRS defaults; implementers MUST override them with their
 * site-specific values via the implementer tools or config JSON.
 */
export const configSchema = {
  /** Location tag UUID that identifies "admission" locations (wards) */
  admissionLocationTagUuid: {
    _type: Type.UUID,
    _description: 'UUID of the "Admission Location" location tag',
    _default: '7d0f0b44-dc7a-11e8-9f8b-f2801f1b9fd1',
  },

  /** Encounter type UUID for bed-assignment (ADT) events */
  admissionEncounterTypeUuid: {
    _type: Type.UUID,
    _description: 'UUID of the Admission encounter type',
    _default: 'e22e39fd-7db2-45e7-80f1-60fa0d5a4378',
  },

  /** Encounter type UUID for IPD visit note/discharge */
  dischargeEncounterTypeUuid: {
    _type: Type.UUID,
    _description: 'UUID of the Discharge encounter type',
    _default: '181820aa-88c9-479b-9077-af92f5364329',
  },

  /** Whether to show medication drug chart in the IPD patient dashboard */
  showMedicationChart: {
    _type: Type.Boolean,
    _description: 'Show the medication drug chart section in the IPD patient dashboard',
    _default: true,
  },

  /** Whether to show nursing tasks section */
  showNursingTasks: {
    _type: Type.Boolean,
    _description: 'Show the nursing tasks section in the IPD patient dashboard',
    _default: true,
  },

  /** Ordered list of sections to display in the patient IPD dashboard */
  ipdDashboardSections: {
    _type: Type.Array,
    _description: 'Ordered list of dashboard sections. Each entry is {componentKey, title, displayOrder}.',
    _elements: {
      _type: Type.Object,
      componentKey: {
        _type: Type.String,
        _description: 'One of AL, VT, DG, TR, NT, DC, IO',
      },
      title: {
        _type: Type.String,
      },
      displayOrder: {
        _type: Type.Number,
      },
    },
    _default: [
      { componentKey: 'AL', title: 'Allergies', displayOrder: 1 },
      { componentKey: 'VT', title: 'Vitals', displayOrder: 2 },
      { componentKey: 'DG', title: 'Diagnosis', displayOrder: 3 },
      { componentKey: 'TR', title: 'Treatments', displayOrder: 4 },
      { componentKey: 'NT', title: 'Nursing Tasks', displayOrder: 5 },
      { componentKey: 'DC', title: 'Drug Chart', displayOrder: 6 },
    ] satisfies DashboardSection[],
  },

  /** Minimum characters required for ward patient search */
  patientSearchMinChars: {
    _type: Type.Number,
    _description: 'Minimum characters to trigger patient search within a ward',
    _default: 3,
  },
};

export type IpdConfig = {
  admissionLocationTagUuid: string;
  admissionEncounterTypeUuid: string;
  dischargeEncounterTypeUuid: string;
  showMedicationChart: boolean;
  showNursingTasks: boolean;
  ipdDashboardSections: DashboardSection[];
  patientSearchMinChars: number;
};
