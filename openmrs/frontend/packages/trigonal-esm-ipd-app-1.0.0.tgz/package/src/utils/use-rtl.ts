import { useEffect, useState } from 'react';

/**
 * useRtl — returns `true` when the O3 shell has set `dir="rtl"` on
 * `<html>`, which happens automatically when the user selects Arabic
 * (or any other RTL locale) via the OpenMRS language selector.
 *
 * ## How O3 handles RTL
 *
 * `@openmrs/esm-primary-navigation-app` reads the user's saved locale from
 * the OpenMRS session and sets `document.documentElement.dir = 'rtl'` when
 * the locale is a right-to-left language (ar, he, fa, ur, …).
 *
 * Carbon Design System v11 reacts to the `dir` attribute automatically:
 * all components use CSS logical properties (`inset-inline-start` instead
 * of `left`, `margin-inline-end` instead of `margin-right`, etc.), so the
 * entire UI mirrors without any additional CSS.
 *
 * Our custom SCSS already uses logical properties throughout (see drug-chart.scss).
 *
 * ## When to use this hook
 *
 * Only needed for imperative JavaScript logic that must differ between LTR
 * and RTL, e.g.:
 * - SVG icon rotation (some directional icons need a 180° flip in RTL)
 * - Canvas / chart drawing
 * - Third-party libs that don't respect CSS direction
 *
 * For styling, rely on CSS logical properties and `dir` attribute — no
 * JavaScript needed.
 *
 * @example
 * ```tsx
 * const isRtl = useRtl();
 * return <ChevronRight style={{ transform: isRtl ? 'scaleX(-1)' : undefined }} />;
 * ```
 */
export function useRtl(): boolean {
  const [isRtl, setIsRtl] = useState<boolean>(
    () => document.documentElement.dir === 'rtl',
  );

  useEffect(() => {
    // Watch for programmatic dir changes (locale switch without page reload)
    const observer = new MutationObserver(() => {
      setIsRtl(document.documentElement.dir === 'rtl');
    });

    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['dir'],
    });

    return () => observer.disconnect();
  }, []);

  return isRtl;
}
