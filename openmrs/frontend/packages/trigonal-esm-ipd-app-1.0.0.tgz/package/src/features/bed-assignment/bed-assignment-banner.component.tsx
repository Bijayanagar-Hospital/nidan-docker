import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button, InlineLoading, Tag, Tile } from '@carbon/react';
import { Hospital } from '@carbon/react/icons';
import { launchWorkspace } from '@openmrs/esm-framework';
import { usePatientBed } from '../patient-ipd/use-ipd-patient';
import { publishAuditEvent } from '../../utils/audit-event';
import type { BedInformation } from '../../types';
import styles from './bed-assignment-banner.scss';

interface BedAssignmentBannerProps {
  patientUuid: string;
  visitUuid: string;
}

/**
 * BedAssignmentBanner — IPD-05
 *
 * Displayed at the top of the patient IPD dashboard (patient-ipd-banner-slot).
 *
 * Shows:
 *   - Current bed number and ward (if assigned)
 *   - Bed status tag (AVAILABLE / OCCUPIED)
 *   - "Assign Bed" or "Reassign Bed" button that opens the
 *     `assign-bed` workspace from @openmrs/esm-bed-management-app
 *
 * ## Workspace integration
 *
 * `@openmrs/esm-bed-management-app` must register a workspace named `assign-bed`.
 * It is listed in `spa-assemble-config.json` as `@openmrs/esm-bed-management-app: "next"`.
 * The workspace receives `{ patientUuid, visitUuid, currentBedId }` as props.
 *
 * Migration note: replaces the legacy Bahmni ADT modal (`PatientMovement.jsx`)
 * which used `axios.post(PATIENT_MOVEMENT_URL)` with a Bahmni encounter type.
 * In O3, bed management is handled by `esm-bed-management-app` via the
 * standard bedmanagement REST module.
 */
const BedAssignmentBanner: React.FC<BedAssignmentBannerProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const { bed, isLoading, mutate } = usePatientBed(patientUuid);

  const typedBed = bed as BedInformation | null;

  const handleAssignBed = () => {
    publishAuditEvent('OPENED_BED_ASSIGNMENT', patientUuid, visitUuid);
    launchWorkspace('assign-bed', {
      patientUuid,
      visitUuid,
      currentBedId: typedBed?.uuid,
      onSuccess: mutate,
    });
  };

  if (isLoading) {
    return (
      <Tile className={styles.banner}>
        <InlineLoading description={t('loadingBed', 'Loading bed assignment…')} />
      </Tile>
    );
  }

  return (
    <Tile className={styles.banner}>
      <div className={styles.bedInfo}>
        <Hospital size={20} className={styles.bedIcon} />

        {typedBed ? (
          <>
            <div className={styles.bedDetails}>
              <span className={styles.bedLabel}>{t('currentBed', 'Current Bed')}</span>
              <span className={styles.bedNumber}>{typedBed.bedNumber}</span>
              <Tag
                type={typedBed.status === 'OCCUPIED' ? 'green' : 'gray'}
                size="sm"
                className={styles.statusTag}
              >
                {t(`bedStatus_${typedBed.status.toLowerCase()}`, typedBed.status)}
              </Tag>
              {typedBed.location?.display && (
                <span className={styles.wardLabel}>
                  {t('ward', 'Ward')}: {typedBed.location.display}
                </span>
              )}
            </div>
            <Button
              kind="tertiary"
              size="sm"
              renderIcon={Hospital}
              onClick={handleAssignBed}
            >
              {t('reassignBed', 'Reassign Bed')}
            </Button>
          </>
        ) : (
          <>
            <span className={styles.noBed}>{t('noBedAssigned', 'No bed assigned')}</span>
            <Button
              kind="primary"
              size="sm"
              renderIcon={Hospital}
              onClick={handleAssignBed}
            >
              {t('assignBed', 'Assign Bed')}
            </Button>
          </>
        )}
      </div>
    </Tile>
  );
};

export default BedAssignmentBanner;
