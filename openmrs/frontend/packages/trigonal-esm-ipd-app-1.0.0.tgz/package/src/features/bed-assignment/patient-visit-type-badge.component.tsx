import React from 'react';
import { Tag } from '@carbon/react';
import { formatDate, useConfig, useVisit } from '@openmrs/esm-framework';
import styles from './bed-assignment-banner.scss';

interface VisitAttributeTagsProps {
  patientUuid: string;
}

/**
 * This extension slots to the patient-banner-tags-slot by default.
 */
const VisitAttributeTags: React.FC<VisitAttributeTagsProps> = ({ patientUuid }) => {
    const { activeVisit } = useVisit(patientUuid);
    const visitType = null;
    if (activeVisit) {
        const visitType = activeVisit.visitType.name;
    }
    if (!visitType) {
        return null;
    }

  return (
    <div className={styles.tagsContainer}>
        <Tag key={visitType} type="gray">
          {visitType}
        </Tag>
    </div>
  );
};

export default VisitAttributeTags;
