import useSWRImmutable from 'swr/immutable';
import { fhirBaseUrl, openmrsFetch, type FetchResponse } from '@openmrs/esm-framework';

const PROBLEM_LIST_CATEGORY =
  'http://terminology.hl7.org/CodeSystem/condition-category|problem-list-item';

/** FHIR R4 Condition resource — minimal subset used in the UI */
export interface FhirCondition {
  id: string;
  resourceType: 'Condition';
  clinicalStatus?: {
    coding: Array<{ code: string; display?: string }>;
  };
  category?: Array<{
    coding: Array<{ code: string; display?: string }>;
  }>;
  code?: {
    coding: Array<{ code: string; display?: string }>;
    text?: string;
  };
  subject?: { reference: string; display?: string };
  onsetDateTime?: string;
  recordedDate?: string;
  recorder?: { reference: string; display?: string };
}

type ConditionBundle = { entry?: Array<{ resource: FhirCondition }> };

/**
 * Fetches FHIR Condition resources (problem list) for a patient.
 *
 * Endpoint: GET /ws/fhir2/R4/Condition?patient={uuid}&category=problem-list-item&_count=100&_summary=data
 */
export function usePatientConditions(patientUuid: string | undefined) {
  const url = patientUuid
    ? `${fhirBaseUrl}/Condition?patient=${patientUuid}&category=${encodeURIComponent(PROBLEM_LIST_CATEGORY)}&_count=100&_summary=data`
    : null;

  const { data, error, isLoading } = useSWRImmutable<FetchResponse<ConditionBundle>, Error>(
    url,
    openmrsFetch,
  );

  return {
    conditions: data?.data?.entry?.map((e) => e.resource) ?? [],
    isLoading,
    error,
  };
}
