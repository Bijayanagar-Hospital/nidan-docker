import React from 'react';
import { useTranslation } from 'react-i18next';
import {
  DataTable,
  DataTableSkeleton,
  InlineNotification,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
} from '@carbon/react';
import { formatDate, parseDate } from '@openmrs/esm-framework';
import { usePatientConditions, type FhirCondition } from './use-patient-conditions';
import { resolveDisplayName } from '../../utils/display';
import styles from './conditions.scss';

type ClinicalStatus = NonNullable<
  NonNullable<FhirCondition['clinicalStatus']>['coding']
>[number]['code'];

const CLINICAL_STATUS_TAG: Record<string, 'green' | 'gray' | 'blue' | 'red' | 'teal'> = {
  active: 'green',
  resolved: 'gray',
  inactive: 'gray',
  recurrence: 'blue',
  relapse: 'red',
  remission: 'teal',
};

const HEADERS = [
  { key: 'condition', header: 'Condition' },
  { key: 'status', header: 'Status' },
  { key: 'onset', header: 'Onset' },
  { key: 'recorded', header: 'Recorded' },
  { key: 'recorder', header: 'Recorder' },
];

function formatDateValue(value: string | undefined): string {
  if (!value) return '—';
  return formatDate(parseDate(value), { mode: 'wide' });
}

function getClinicalStatus(condition: FhirCondition): string | undefined {
  return condition.clinicalStatus?.coding?.[0]?.code;
}

interface ConditionsProps {
  patientUuid: string;
}

/**
 * Conditions — problem list table backed by FHIR R4 Condition resources.
 *
 * Columns: Condition | Status | Onset | Recorded | Recorder
 */
const Conditions: React.FC<ConditionsProps> = ({ patientUuid }) => {
  const { t } = useTranslation();
  const { conditions, isLoading, error } = usePatientConditions(patientUuid);

  if (isLoading) {
    return <DataTableSkeleton columnCount={HEADERS.length} rowCount={3} />;
  }

  if (error) {
    return (
      <InlineNotification
        kind="error"
        title={t('conditionsLoadError', 'Failed to load conditions')}
        subtitle={error.message}
      />
    );
  }

  if (conditions.length === 0) {
    return <p className={styles.empty}>{t('noConditions', 'No conditions recorded')}</p>;
  }

  const rows = conditions.map((condition) => {
    const status = getClinicalStatus(condition);

    return {
      id: condition.id,
      condition: resolveDisplayName(
        condition.code?.text ?? condition.code?.coding?.[0]?.display ?? '—',
      ),
      status: status ? (
        <Tag type={CLINICAL_STATUS_TAG[status] ?? 'gray'} size="sm">
          {t(`clinicalStatus_${status}`, status)}
        </Tag>
      ) : (
        '—'
      ),
      onset: formatDateValue(condition.onsetDateTime),
      recorded: formatDateValue(condition.recordedDate),
      recorder: resolveDisplayName(condition.recorder?.display) || '—',
    };
  });

  return (
    <DataTable rows={rows} headers={HEADERS}>
      {({ rows: tableRows, headers, getTableProps, getHeaderProps, getRowProps }) => (
        <TableContainer>
          <Table {...getTableProps()} size="lg">
            <TableHead>
              <TableRow>
                {headers.map((h) => {
                  const { onClick, ...rest } = getHeaderProps({ header: h });
                  return (
                    <TableHeader
                      {...rest}
                      onClick={onClick as unknown as React.MouseEventHandler<HTMLButtonElement>}
                    >
                      {h.header}
                    </TableHeader>
                  );
                })}
              </TableRow>
            </TableHead>
            <TableBody>
              {tableRows.map((row) => (
                <TableRow {...getRowProps({ row })} key={row.id}>
                  {row.cells.map((cell) => (
                    <TableCell key={cell.id}>{cell.value}</TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </DataTable>
  );
};

export default Conditions;
