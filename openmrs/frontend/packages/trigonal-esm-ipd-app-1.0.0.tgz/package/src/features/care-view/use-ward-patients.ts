import useSWR from 'swr';
import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import type {
  AdmissionLocation,
  AdmittedPatient,
  RestApiResult,
  WardSummary,
} from '../../types';

/**
 * Fetches all admission locations (wards) from the OpenMRS REST API.
 *
 * Endpoint: GET /ws/rest/v1/admissionLocation
 */
export function useWards() {
  const url = `${restBaseUrl}/admissionLocation?v=default`;

  const { data, error, isLoading, mutate } = useSWR<FetchResponse<{ results: AdmissionLocation[] }>, Error>(
    url,
    openmrsFetch,
  );

  return {
    wards: data?.data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}

/**
 * Fetches the summary (total/my patients) for a specific ward.
 *
 * Endpoint: GET /ws/rest/v1/ipd/wards/{wardId}/summary
 */
export function useWardSummary(wardUuid: string | undefined) {
  const url = wardUuid ? `${restBaseUrl}/ipd/wards/${wardUuid}/summary` : null;

  const { data, error, isLoading, mutate } = useSWR<FetchResponse<WardSummary>, Error>(
    url,
    openmrsFetch,
  );

  return {
    summary: data?.data,
    isLoading,
    error,
    mutate,
  };
}

/**
 * Fetches the list of admitted patients for a ward.
 *
 * Supports three modes:
 * 1. All patients:    GET /ws/rest/v1/ipd/wards/{wardId}/patients
 * 2. My patients:     GET /ws/rest/v1/ipd/wards/{wardId}/myPatients   (providerUuid set)
 * 3. Searched:        GET /ws/rest/v1/ipd/wards/{wardId}/patients/search?q={query}
 *
 * The `refresh` parameter is a boolean toggle — every flip forces a revalidation.
 */
export function useAdmittedPatients(
  wardUuid: string | undefined,
  providerUuid: string | undefined,
  searchQuery: string,
  refresh: boolean,
) {
  const baseUrl = wardUuid
    ? searchQuery
      ? `${restBaseUrl}/ipd/wards/${wardUuid}/patients/search?q=${encodeURIComponent(searchQuery)}`
      : providerUuid
        ? `${restBaseUrl}/ipd/wards/${wardUuid}/myPatients`
        : `${restBaseUrl}/ipd/wards/${wardUuid}/patients`
    : null;

  // Include `refresh` in the SWR key so toggling it triggers revalidation.
  // Because the key is a tuple, we use a custom fetcher that extracts the URL.
  const swrKey = baseUrl ? [baseUrl, refresh] : null;

  const { data, error, isLoading, mutate } = useSWR<FetchResponse<RestApiResult<AdmittedPatient>>, Error>(
    swrKey,
    ([u]: [string]) => openmrsFetch<RestApiResult<AdmittedPatient>>(u),
  );

  return {
    patients: data?.data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}

