import useSWR from 'swr';
import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import type {
  AdmissionLocation,
  AdmittedPatient,
  RestApiResult,
  WardSummary,
} from '../../types';

/**
 * Fetches all admission locations (wards) from the OpenMRS REST API.
 *
 * Migration note: replaces `axios.get(LIST_OF_WARDS_URL)` and the
 * manual loading/error state management in CareViewDashboard.
 *
 * Endpoint: GET /ws/rest/v1/admissionLocation
 */
export function useWards() {
  const url = `${restBaseUrl}/admissionLocation?v=default`;

  const { data, error, isLoading, mutate } = useSWR<{ results: AdmissionLocation[] }, Error>(
    url,
    (u: string) => openmrsFetch<{ results: AdmissionLocation[] }>(u).then((r) => r.data),
  );

  return {
    wards: data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}

/**
 * Fetches the summary (total/my patients) for a specific ward.
 *
 * Migration note: replaces `axios.get(WARD_SUMMARY_URL.replace('{wardId}', id))`
 * called inside getIpdConfig(). SWR will only fetch when `wardUuid` is truthy.
 *
 * Endpoint: GET /ws/rest/v1/ipd/wards/{wardId}/summary
 */
export function useWardSummary(wardUuid: string | undefined) {
  const url = wardUuid ? `${restBaseUrl}/ipd/wards/${wardUuid}/summary` : null;

  const { data, error, isLoading, mutate } = useSWR<WardSummary, Error>(
    url,
    (u: string) => openmrsFetch<WardSummary>(u).then((r) => r.data),
  );

  return {
    summary: data,
    isLoading,
    error,
    mutate,
  };
}

/**
 * Fetches the list of admitted patients for a ward.
 *
 * Supports three modes:
 * 1. All patients:    GET /ws/rest/v1/ipd/wards/{wardId}/patients
 * 2. My patients:     GET /ws/rest/v1/ipd/wards/{wardId}/myPatients   (providerUuid set)
 * 3. Searched:        GET /ws/rest/v1/ipd/wards/{wardId}/patients/search?q={query}
 *
 * Migration note: replaces three separate axios calls in CareViewPatients.jsx
 * controlled by state props. The SWR key is a tuple [url, providerUuid, query]
 * which changes when any filter changes, triggering a fresh fetch.
 *
 * The `refresh` parameter is a boolean toggle — every flip forces a revalidation.
 */
export function useAdmittedPatients(
  wardUuid: string | undefined,
  providerUuid: string | undefined,
  searchQuery: string,
  refresh: boolean,
) {
  const baseUrl = wardUuid
    ? searchQuery
      ? `${restBaseUrl}/ipd/wards/${wardUuid}/patients/search?q=${encodeURIComponent(searchQuery)}`
      : providerUuid
        ? `${restBaseUrl}/ipd/wards/${wardUuid}/myPatients`
        : `${restBaseUrl}/ipd/wards/${wardUuid}/patients`
    : null;

  // Include `refresh` in the SWR key so toggling it triggers revalidation
  const swrKey = baseUrl ? [baseUrl, refresh] : null;

  const { data, error, isLoading, mutate } = useSWR<RestApiResult<AdmittedPatient>, Error>(
    swrKey,
    ([u]: [string]) => openmrsFetch<RestApiResult<AdmittedPatient>>(u).then((r) => r.data),
  );

  return {
    patients: data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}
