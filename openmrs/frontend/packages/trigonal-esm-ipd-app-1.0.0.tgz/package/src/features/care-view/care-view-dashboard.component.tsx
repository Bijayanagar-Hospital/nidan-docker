import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  DataTable,
  DataTableSkeleton,
  InlineNotification,
  Layer,
  Search,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
  Tile,
} from '@carbon/react';
import { Hospital } from '@carbon/react/icons';
import { ConfigurableLink, useConfig, useSession } from '@openmrs/esm-framework';
import { useAdmittedPatients, useWards, useWardSummary } from './use-ward-patients';
import { WARD_SUMMARY_HEADER, type WardSummaryHeader } from '../../constants';
import type { AdmissionLocation, CareViewContextValue } from '../../types';
import type { IpdConfig } from '../../config-schema';
import { resolveDisplayName } from '../../utils/display';
import styles from './care-view-dashboard.scss';

/** ─── Context ────────────────────────────────────────────────────────────── */
export const CareViewContext = createContext<CareViewContextValue>({
  selectedWard: {},
  setSelectedWard: () => {},
  wardSummary: {},
  setWardSummary: () => {},
  headerSelected: WARD_SUMMARY_HEADER.TOTAL_PATIENTS,
  setHeaderSelected: () => {},
  refreshPatientList: false,
  handleRefreshPatientList: () => {},
  refreshSummary: false,
  handleRefreshSummary: () => {},
});

export const useCareViewContext = () => useContext(CareViewContext);

/** ─── Summary tile ───────────────────────────────────────────────────────── */
interface SummaryTileProps {
  label: string;
  count: number;
  isActive: boolean;
  onClick: () => void;
}

const SummaryTile: React.FC<SummaryTileProps> = ({ label, count, isActive, onClick }) => (
  <Tile
    className={`${styles.summaryTile} ${isActive ? styles.summaryTileActive : ''}`}
    onClick={onClick}
  >
    <p className={styles.summaryCount}>{count}</p>
    <p className={styles.summaryLabel}>{label}</p>
  </Tile>
);

/** ─── Ward patient table ─────────────────────────────────────────────────── */
const HEADERS = [
  { key: 'name', header: 'Patient Name' },
  { key: 'identifier', header: 'ID' },
  { key: 'bed', header: 'Bed' },
  { key: 'age', header: 'Age' },
  { key: 'gender', header: 'Gender' },
  { key: 'admissionDate', header: 'Admitted' },
  { key: 'actions', header: '' },
];

/** ─── Main dashboard ─────────────────────────────────────────────────────── */

/**
 * CareViewDashboard — the ward-level IPD overview.
 *
 * ## Migration delta vs legacy CareViewDashboard.jsx
 *
 * | Legacy                            | O3 replacement                        |
 * |-----------------------------------|---------------------------------------|
 * | `hostApi.onLogOut`                | `useSession()` + navigate to /logout  |
 * | `hostData.provider`               | `useSession().currentProvider`        |
 * | `getDashboardConfig()` (axios)    | `useConfig<IpdConfig>()`              |
 * | `getConfigForCareViewDashboard()` | `useConfig<IpdConfig>()`              |
 * | `carbon-components-react` v7      | `@carbon/react` v1 (Carbon v11)       |
 * | `react-intl` / I18nProvider       | `react-i18next` / useTranslation()    |
 * | Manual audit-event calls          | OpenMRS Global Event Bus (future)     |
 * | `Home24` icon from `@carbon/icons-react` v10 | `Hospital` from `@carbon/react/icons` |
 * | `<Header>` layout                 | O3 `<PageHeader>` + `useNavigate`     |
 */
const CareViewDashboard: React.FC = () => {
  const { t } = useTranslation();
  const config = useConfig<IpdConfig>();
  const { user } = useSession();

  const [selectedWard, setSelectedWard] = useState<Partial<AdmissionLocation>>({});
  const [headerSelected, setHeaderSelected] = useState<WardSummaryHeader>(
    WARD_SUMMARY_HEADER.TOTAL_PATIENTS,
  );
  const [wardSummary, setWardSummary] = useState<Record<string, unknown>>({});
  const [refreshPatientList, setRefreshPatientList] = useState(false);
  const [refreshSummary, setRefreshSummary] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const { wards, isLoading: wardsLoading, error: wardsError } = useWards();
  const { summary, isLoading: summaryLoading } = useWardSummary(selectedWard?.uuid);
  const { patients, isLoading: patientsLoading } = useAdmittedPatients(
    selectedWard?.uuid,
    headerSelected === WARD_SUMMARY_HEADER.MY_PATIENTS ? user?.uuid : undefined,
    searchQuery.length >= config.patientSearchMinChars ? searchQuery : '',
    refreshPatientList,
  );

  const handleRefreshPatientList = useCallback(() => setRefreshPatientList((v) => !v), []);
  const handleRefreshSummary = useCallback(() => setRefreshSummary((v) => !v), []);

  const ctxValue = useMemo<CareViewContextValue>(
    () => ({
      selectedWard,
      setSelectedWard,
      wardSummary,
      setWardSummary,
      headerSelected,
      setHeaderSelected: (h: string) => setHeaderSelected(h as WardSummaryHeader),
      refreshPatientList,
      handleRefreshPatientList,
      refreshSummary,
      handleRefreshSummary,
    }),
    [
      selectedWard,
      wardSummary,
      headerSelected,
      refreshPatientList,
      refreshSummary,
      handleRefreshPatientList,
      handleRefreshSummary,
    ],
  );

  const tableRows = useMemo(
    () =>
      patients.map((ap) => ({
        id: ap.patient.uuid,
        name: (
          <ConfigurableLink
            to={`${window.getOpenmrsSpaBase()}patient/${ap.patient.uuid}/chart/ipd-summary`}
          >
            {ap.patient.person.display}
          </ConfigurableLink>
        ),
        identifier:
          resolveDisplayName(ap.patient.identifiers.find((i) => i.preferred)?.identifier) ?? '—',
        bed: resolveDisplayName(ap.bed?.bedNumber) ?? t('noBed', 'No Bed'),
        age: resolveDisplayName(ap.patient.person.age) ?? '—',
        gender: resolveDisplayName(ap.patient.person.gender) ?? '—',
        admissionDate: ap.visit?.startDatetime
          ? new Date(ap.visit.startDatetime).toLocaleDateString()
          : '—',
        actions: (
          <Button
            kind="ghost"
            size="sm"
            renderIcon={Hospital}
            iconDescription={t('openIpd', 'Open IPD')}
            href={`${window.getOpenmrsSpaBase()}patient/${ap.patient.uuid}/chart/ipd-summary`}
          >
            {t('viewIpd', 'View IPD')}
          </Button>
        ),
      })),
    [patients, t],
  );

  if (wardsLoading) {
    return <DataTableSkeleton columnCount={HEADERS.length} rowCount={5} />;
  }

  if (wardsError) {
    return (
      <InlineNotification
        kind="error"
        title={t('wardsLoadError', 'Failed to load wards')}
        subtitle={String(wardsError.message)}
      />
    );
  }

  return (
    <CareViewContext.Provider value={ctxValue}>
      <main className={styles.careViewPage}>
        {/* Ward selector */}
        <section className={styles.wardSelector}>
          <h2 className={styles.wardSelectorTitle}>{t('selectWard', 'Select Ward')}</h2>
          <div className={styles.wardChips}>
            {wards.map((ward) => (
              <Tag
                key={ward.uuid}
                type={selectedWard?.uuid === ward.uuid ? 'blue' : 'gray'}
                className={styles.wardChip}
                onClick={() => setSelectedWard(ward)}
              >
                {ward.display}
              </Tag>
            ))}
          </div>
        </section>

        {/* Summary tiles */}
        {selectedWard?.uuid && (
          <section className={styles.summarySection}>
            {summaryLoading ? (
              <DataTableSkeleton columnCount={2} rowCount={1} />
            ) : (
              <div className={styles.summaryTiles}>
                <SummaryTile
                  label={t('totalPatients', 'Total Patients')}
                  count={summary?.totalPatients ?? 0}
                  isActive={headerSelected === WARD_SUMMARY_HEADER.TOTAL_PATIENTS}
                  onClick={() => setHeaderSelected(WARD_SUMMARY_HEADER.TOTAL_PATIENTS)}
                />
                <SummaryTile
                  label={t('myPatients', 'My Patients')}
                  count={summary?.myPatients ?? 0}
                  isActive={headerSelected === WARD_SUMMARY_HEADER.MY_PATIENTS}
                  onClick={() => setHeaderSelected(WARD_SUMMARY_HEADER.MY_PATIENTS)}
                />
              </div>
            )}
          </section>
        )}

        {/* Patient list */}
        {selectedWard?.uuid && (
          <section className={styles.patientList}>
            <Layer>
              <Search
                labelText={t('searchPatients', 'Search patients')}
                placeholder={t(
                  'searchPlaceholder',
                  'Type min. {{count}} characters to search',
                  { count: config.patientSearchMinChars },
                )}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                size="md"
              />
            </Layer>

            {patientsLoading ? (
              <DataTableSkeleton columnCount={HEADERS.length} rowCount={8} />
            ) : (
              <DataTable rows={tableRows} headers={HEADERS} isSortable>
                {({ rows, headers, getTableProps, getHeaderProps, getRowProps }) => (
                  <TableContainer>
                    <Table {...getTableProps()}>
                      <TableHead>
                        <TableRow>
                          {headers.map((header) => {
                            // Carbon's getHeaderProps onClick uses DOM MouseEvent; cast to satisfy
                            // React's stricter MouseEventHandler<HTMLButtonElement> expectation.
                            const { onClick, ...restHeaderProps } = getHeaderProps({ header });
                            return (
                              <TableHeader
                                key={header.key}
                                {...restHeaderProps}
                                onClick={onClick as unknown as React.MouseEventHandler<HTMLButtonElement>}
                              >
                                {header.header}
                              </TableHeader>
                            );
                          })}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {rows.map((row) => (
                          <TableRow {...getRowProps({ row })} key={row.id}>
                            {row.cells.map((cell) => (
                              <TableCell key={cell.id}>{resolveDisplayName(cell.value)}</TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
              </DataTable>
            )}
          </section>
        )}
      </main>
    </CareViewContext.Provider>
  );
};

export default CareViewDashboard;
