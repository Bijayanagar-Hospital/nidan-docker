/**
 * needs support of nidan-esm-nepali-calendar microfrontend
 * Bikram Sambat (BS) calendar formatting utility
 *
 * The @openmrs/esm-framework `formatDate` / `formatDatetime` functions already
 * embed the BS date when the instance locale is configured for Nepal.
 *
 * Framework output examples:
 *   formatDatetime(d) → "06 — Jul — 2026, 07:03 AM (BS 2083-03-22)"
 *   formatDate(d)     → "24 — Jun — 2026 (BS 2083-03-10)"
 *
 * This module extracts that embedded `(BS YYYY-MM-DD)` suffix and converts
 * the numeric month into a Nepali month name so we can display e.g.
 * "10 Ashadh, 1:00 PM" — without maintaining any separate conversion table.
 */

import { formatDate, formatDatetime } from '@openmrs/esm-framework';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

export const BS_MONTHS = [
  'Baisakh',
  'Jestha',
  'Ashadh',
  'Shrawan',
  'Bhadra',
  'Ashwin',
  'Kartik',
  'Mangsir',
  'Poush',
  'Magh',
  'Falgun',
  'Chaitra',
] as const;

export type BsMonth = (typeof BS_MONTHS)[number];

/** Matches the `(BS YYYY-MM-DD)` suffix appended by the framework */
const BS_SUFFIX_RE = /\(BS\s+(\d{4})-(\d{2})-(\d{2})\)/;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface BsDate {
  year: number;
  /** 1-indexed month (1 = Baisakh … 12 = Chaitra) */
  month: number;
  day: number;
}

// ---------------------------------------------------------------------------
// Core helpers
// ---------------------------------------------------------------------------

/**
 * Parse the `(BS YYYY-MM-DD)` suffix embedded in a framework-formatted string.
 * Returns `null` when the suffix is absent (locale not configured for BS).
 */
export function extractBsDate(formattedStr: string): BsDate | null {
  const m = BS_SUFFIX_RE.exec(formattedStr);
  if (!m) return null;
  return {
    year: parseInt(m[1], 10),
    month: parseInt(m[2], 10),
    day: parseInt(m[3], 10),
  };
}

/**
 * Return the BS month name for a 1-indexed month number.
 * e.g. `bsMonthName(3)` → `"Ashadh"`
 */
export function bsMonthName(month: number): BsMonth {
  return BS_MONTHS[(month - 1) % 12];
}

/**
 * Derive a `BsDate` from a JS `Date` by asking the framework to format it
 * and parsing the embedded BS suffix.
 *
 * Returns `null` when the framework output contains no BS suffix (i.e. the
 * instance is not configured for the Nepali locale).
 */
export function getBsDate(adDate: Date): BsDate | null {
  // formatDate (date-only) keeps the string short and reliable to parse
  const formatted = formatDate(adDate, { mode: 'wide', time: false });
  return extractBsDate(formatted);
}

/**
 * Returns `true` when the current OpenMRS framework locale is configured to
 * include BS dates in formatted output.
 *
 * Use this to decide whether to render the AD/BS toggle at all — no point
 * showing it when `formatDate` only returns an English/Gregorian string.
 */
export function isBsEnabled(): boolean {
  return getBsDate(new Date()) !== null;
}

// ---------------------------------------------------------------------------
// Formatting helpers used by components
// ---------------------------------------------------------------------------

/**
 * 12-hour time string from a JS Date.
 * e.g. `"1:00 PM"`
 */
export function formatBsTime(adDate: Date): string {
  return adDate.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
}

/**
 * Short BS date string.
 * - `includeYear = false` (default) → `"10 Ashadh"`
 * - `includeYear = true`            → `"10 Ashadh 2083"`
 *
 * Falls back to a short locale date when no BS suffix is available.
 */
export function formatBsDate(adDate: Date, includeYear = false): string {
  const bs = getBsDate(adDate);
  if (!bs) {
    return adDate.toLocaleDateString([], { day: 'numeric', month: 'short' });
  }
  const name = bsMonthName(bs.month);
  return includeYear ? `${bs.day} ${name} ${bs.year}` : `${bs.day} ${name}`;
}

/**
 * Full BS datetime string for shift headers.
 * - `includeYear = false` (default) → `"10 Ashadh, 1:00 PM"`
 * - `includeYear = true`            → `"10 Ashadh 2083, 1:00 PM"`
 *
 * Falls back to a short locale datetime when no BS suffix is available.
 */
export function formatBsDateTime(adDate: Date, includeYear = false): string {
  const bs = getBsDate(adDate);
  if (!bs) {
    return adDate.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  const name = bsMonthName(bs.month);
  const datePart = includeYear ? `${bs.day} ${name} ${bs.year}` : `${bs.day} ${name}`;
  return `${datePart}, ${formatBsTime(adDate)}`;
}
