import React from 'react';
import { Tag, ClickableTile } from '@carbon/react';
import { Medication as MedicationIcon, Activity as TaskIcon } from '@carbon/react/icons';
import { resolveDisplayName } from './nursing-tasks.utils';
import styles from './nursing-tasks.scss';

export interface TaskTileProps {
  taskUuid: string;
  name: string;
  status: string;
  isMedication: boolean;
  dosage?: string;
  time?: string;
  actualTime?: string;
  isLate?: boolean;
  creator?: string;
  disabled?: boolean;
  asNeeded?: boolean;
  onClick: () => void;
}

export const TaskTile: React.FC<TaskTileProps> = ({
  name,
  status,
  isMedication,
  dosage,
  time,
  actualTime,
  isLate,
  creator,
  disabled,
  asNeeded,
  onClick,
}) => {
  const isCompleted = status === 'COMPLETED' || status === 'completed';
  const isPending = status === 'REQUESTED' || status === 'IN_PROGRESS';
  const isSkipped = status === 'not-done' || status === 'NOT_DONE' || status === 'CANCELLED' || status === 'STOPPED' || status === 'Cancelled';

  return (
    <ClickableTile
      onClick={disabled ? undefined : onClick}
      className={`${styles.taskTile} ${isCompleted ? styles.completedTask : ''} ${disabled ? styles.disabledTask : ''}`}
    >
      <div className={styles.tileHeader}>
        <div className={styles.tileIcon}>
          {isMedication ? <MedicationIcon size={20} /> : <TaskIcon size={20} />}
        </div>
        <div className={styles.tileTitle}>
          <span className={isCompleted ? styles.completedText : ''}>{resolveDisplayName(name)}</span>
          <br />
          {dosage && <span className={styles.tileSubtext}>{dosage}</span>}
        </div>
        <div className={styles.tileStatus}>
          {asNeeded && (
            <Tag type="blue" size="sm" className="mr-2">
              As Needed
            </Tag>
          )}
          <Tag type={isCompleted || isSkipped ? 'gray' : isPending ? 'blue' : 'red'}>{status}</Tag>
        </div>
      </div>
      {(isCompleted || !asNeeded) && (
        <div className={styles.tileFooter}>
          <div className={styles.tileTime}>
            {time && <span>{time}</span>}
            {isCompleted && actualTime && (
              <>
                <span> - </span>
                <span className={isLate ? styles.lateTime : styles.onTime}>{actualTime}</span>
                <span>(actual)</span>
              </>
            )}
          </div>
          {creator && <span className={styles.tileCreator}>User: {creator}</span>}
        </div>
      )}
    </ClickableTile>
  );
};
