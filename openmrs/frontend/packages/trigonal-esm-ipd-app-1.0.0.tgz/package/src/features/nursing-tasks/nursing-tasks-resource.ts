import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import type { NursingTask } from '../../types';

export interface CreateTaskPayload {
  name: string;
  description?: string;
  intent: 'order' | 'proposal';
  status: 'REQUESTED';
  priority: 'routine' | 'urgent' | 'stat';
  patient: { uuid: string };
  taskType?: { uuid: string };
  executionPeriod?: { start: string; end?: string };
}

export interface UpdateTaskPayload {
  status: NursingTask['status'];
  notes?: string;
}

/**
 * POST /ws/rest/v1/tasks — create a new nursing task.
 *
 * Migration note: replaces the legacy `axios.post(NON_MEDICATION_BASE_URL, payload)`
 * call in the Bahmni IPD add-task form.
 */
export async function createNursingTask(payload: CreateTaskPayload): Promise<NursingTask> {
  const { data } = await openmrsFetch<NursingTask>(`${restBaseUrl}/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return data;
}

/**
 * POST /ws/rest/v1/tasks/{uuid} — update task status (start/complete/cancel).
 */
export async function updateNursingTask(
  taskUuid: string,
  payload: UpdateTaskPayload,
): Promise<NursingTask> {
  const { data } = await openmrsFetch<NursingTask>(`${restBaseUrl}/tasks/${taskUuid}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return data;
}
