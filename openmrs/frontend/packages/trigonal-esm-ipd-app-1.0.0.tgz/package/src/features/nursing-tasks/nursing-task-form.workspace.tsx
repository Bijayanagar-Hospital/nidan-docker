import React, { useCallback } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import {
  Button,
  ButtonSet,
  DatePicker,
  DatePickerInput,
  Form,
  FormGroup,
  InlineNotification,
  RadioButton,
  RadioButtonGroup,
  Stack,
  TextArea,
  TextInput,
} from '@carbon/react';
import { closeWorkspace, showSnackbar } from '@openmrs/esm-framework';
import { createNursingTask } from './nursing-tasks-resource';
import styles from './nursing-task-form.scss';

/** ─── Validation schema ──────────────────────────────────────────────────── */
const taskSchema = z.object({
  name: z
    .string()
    .min(3, 'taskNameMinLength')
    .max(255),
  description: z.string().max(1000).optional(),
  priority: z.enum(['routine', 'urgent', 'stat']),
  dueDate: z.date().optional(),
});

type TaskFormValues = z.infer<typeof taskSchema>;

interface NursingTaskFormWorkspaceProps {
  patientUuid: string;
  visitUuid: string;
  /** SWR mutate function to refresh the task list on success */
  mutateTaskList: () => void;
}

/**
 * NursingTaskFormWorkspace — IPD-02
 *
 * Opened via launchWorkspace('add-ipd-task', { patientUuid, visitUuid, mutateTaskList }).
 *
 * Uses react-hook-form for state management and zod for schema-based validation.
 * No `any` types; all field values are inferred from the zod schema.
 *
 * Migration note: replaces the legacy uncontrolled form inside AddNursingTasks.jsx
 * which used manual `useState` for every field and axios for submission.
 */
const NursingTaskFormWorkspace: React.FC<NursingTaskFormWorkspaceProps> = ({
  patientUuid,
  visitUuid,
  mutateTaskList,
}) => {
  const { t } = useTranslation();

  const {
    register,
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<TaskFormValues>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      priority: 'routine',
    },
  });

  const onSubmit = useCallback(
    async (values: TaskFormValues) => {
      try {
        await createNursingTask({
          name: values.name,
          description: values.description,
          intent: 'order',
          status: 'REQUESTED',
          priority: values.priority,
          patient: { uuid: patientUuid },
          executionPeriod: values.dueDate
            ? { start: values.dueDate.toISOString() }
            : undefined,
        });

        showSnackbar({
          title: t('taskSaved', 'Task saved successfully'),
          kind: 'success',
          isLowContrast: true,
        });

        mutateTaskList();
        closeWorkspace('add-ipd-task', { ignoreChanges: true });
      } catch (err) {
        showSnackbar({
          title: t('taskSaveError', 'Failed to save task'),
          subtitle: err instanceof Error ? err.message : String(err),
          kind: 'error',
        });
      }
    },
    [patientUuid, mutateTaskList, t],
  );

  const handleCancel = useCallback(() => {
    closeWorkspace('add-ipd-task');
  }, []);

  return (
    <Form onSubmit={handleSubmit(onSubmit)} className={styles.form}>
      <Stack gap={6}>
        {/* Task name */}
        <TextInput
          id="task-name"
          labelText={t('taskName', 'Task Name')}
          placeholder={t('taskNamePlaceholder', 'e.g. Turn patient q2h')}
          invalid={!!errors.name}
          invalidText={errors.name ? t(errors.name.message ?? 'taskNameRequired', 'Task name is required') : undefined}
          {...register('name')}
        />

        {/* Description */}
        <TextArea
          id="task-description"
          labelText={t('taskDescription', 'Description')}
          rows={3}
          placeholder={t('taskDescriptionPlaceholder', 'Optional — add clinical notes')}
          invalid={!!errors.description}
          invalidText={errors.description?.message}
          {...register('description')}
        />

        {/* Priority */}
        <FormGroup legendText={t('taskPriority', 'Priority')}>
          <Controller
            name="priority"
            control={control}
            render={({ field }) => (
              <RadioButtonGroup
                name="priority"
                valueSelected={field.value}
                onChange={field.onChange}
                orientation="horizontal"
              >
                <RadioButton
                  labelText={t('priorityRoutine', 'Routine')}
                  value="routine"
                  id="priority-routine"
                />
                <RadioButton
                  labelText={t('priorityUrgent', 'Urgent')}
                  value="urgent"
                  id="priority-urgent"
                />
                <RadioButton
                  labelText={t('priorityStat', 'STAT')}
                  value="stat"
                  id="priority-stat"
                />
              </RadioButtonGroup>
            )}
          />
        </FormGroup>

        {/* Due date */}
        <Controller
          name="dueDate"
          control={control}
          render={({ field }) => (
            <DatePicker
              datePickerType="single"
              dateFormat="d/m/Y"
              minDate={new Date().toLocaleDateString('en-GB')}
              onChange={([date]) => field.onChange(date)}
              value={field.value ? [field.value] : []}
            >
              <DatePickerInput
                id="task-due-date"
                labelText={t('taskDueDate', 'Due Date')}
                placeholder="dd/mm/yyyy"
                invalid={!!errors.dueDate}
                invalidText={errors.dueDate?.message}
              />
            </DatePicker>
          )}
        />

        {/* Form-level error (unlikely but safe) */}
        {errors.root && (
          <InlineNotification kind="error" title={errors.root.message} />
        )}
      </Stack>

      {/* ── Actions ─────────────────────────────────────────────────── */}
      <ButtonSet className={styles.buttonSet}>
        <Button kind="secondary" onClick={handleCancel} disabled={isSubmitting}>
          {t('cancel', 'Cancel')}
        </Button>
        <Button kind="primary" type="submit" disabled={isSubmitting}>
          {isSubmitting
            ? t('saving', 'Saving…')
            : t('saveTask', 'Save Task')}
        </Button>
      </ButtonSet>
    </Form>
  );
};

export default NursingTaskFormWorkspace;
