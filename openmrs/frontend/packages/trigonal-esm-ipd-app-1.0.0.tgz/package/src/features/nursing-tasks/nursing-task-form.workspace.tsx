import React, { useCallback, useState } from 'react';
import useSWR from 'swr';
import useSWRImmutable from 'swr/immutable';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import {
  Button,
  ButtonSet,
  Form,
  FormGroup,
  InlineNotification,
  Stack,
  TextArea,
  TextInput,
  Select,
  SelectItem,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  ComboBox,
  Toggle,
} from '@carbon/react';
import { showSnackbar, Workspace2, useSession, openmrsFetch, restBaseUrl, useConfig, OpenmrsDatePicker } from '@openmrs/esm-framework';
import { type PatientWorkspace2DefinitionProps } from '@openmrs/esm-patient-common-lib';
import { createNursingTask, createAdhocMedicationAdministration, updateNursingTask } from './nursing-tasks-resource';
import styles from './nursing-task-form.scss';

/** ─── Validation schema ──────────────────────────────────────────────────── */

// Standard non-medication task schema
const nonMedicationSchema = z.object({
  taskName: z.string().min(3, 'Task name is required').max(255),
  taskType: z.string().optional(),
  scheduleTime: z.string().min(4, 'Schedule time is required'),
});

// Medication ad-hoc task schema
const medicationSchema = z.object({
  drugUuid: z.string().min(1, 'Drug is required'),
  dose: z.coerce.number().min(1, 'Dose must be greater than 0'),
  doseUnits: z.string().min(1, 'Units required'),
  route: z.string().min(1, 'Route required'),
  adminDate: z.date({ required_error: 'Date required' }),
  adminTime: z.string().min(4, 'Time is required'),
  provider: z.string().min(2, 'Provider name is required'),
  notes: z.string().min(1, 'Notes are required').max(250),
});

type NonMedicationFormValues = z.infer<typeof nonMedicationSchema>;
type MedicationFormValues = z.infer<typeof medicationSchema>;

interface NursingTaskFormWorkspaceProps {
  mutateTaskList: () => void;
}

const NursingTaskFormWorkspace: React.FC<PatientWorkspace2DefinitionProps<NursingTaskFormWorkspaceProps, any>> = ({
  groupProps: { patient, visitContext },
  workspaceProps: { mutateTaskList },
  closeWorkspace,
}) => {
  const patientUuid = patient.id;
  const visitUuid = visitContext?.uuid;
  const { t } = useTranslation();
  const session = useSession();
  const [activeTab, setActiveTab] = useState<'medication' | 'non-medication'>('medication');
  const [drugSearchText, setDrugSearchText] = useState('');
  const [debouncedDrugSearchText, setDebouncedDrugSearchText] = useState('');

  React.useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedDrugSearchText(drugSearchText);
    }, 400);
    return () => clearTimeout(handler);
  }, [drugSearchText]);

  // Fetch Providers dynamically
  const { data: providers } = useSWR<any[]>(
    `${restBaseUrl}/provider?v=custom:(uuid,display,person:(display),attributes:(attributeType:(display),value))`,
    (url: string) =>
      openmrsFetch(url).then((res) =>
        res.data.results.filter((provider: any) =>
          provider.attributes?.some(
            (attr: any) =>
              attr.attributeType?.display === 'practitioner_type' &&
              attr.value?.toLowerCase() === 'doctor'
          )
        )
      )
  );

  // Fetch Drugs dynamically
  const { data: drugs } = useSWR<any[]>(
    debouncedDrugSearchText ? `${restBaseUrl}/drug?q=${encodeURIComponent(debouncedDrugSearchText)}&v=custom:(uuid,display,name,strength,dosageForm:(display,uuid),concept:(display,uuid))` : null,
    (url: any) => openmrsFetch(url).then(res => res.data.results)
  );
  
  const config = useConfig();
  const taskTypesConceptUuid = config.concepts.nursingTaskTypesConceptSetUuid;

  // Fetch task types from concept set
  const { data: taskTypesConcept } = useSWRImmutable<any>(
    taskTypesConceptUuid ? `${restBaseUrl}/concept/${taskTypesConceptUuid}?v=custom:(uuid,display,setMembers:(uuid,display))` : null,
    (url: string) => openmrsFetch(url).then((res) => res.data),
  );

  const taskTypes = taskTypesConcept?.setMembers || [];

  // Fetch Order Entry Config (routes, units, etc.)
  const { data: orderConfig } = useSWRImmutable<any>(`${restBaseUrl}/orderentryconfig`, (url: string) =>
    openmrsFetch(url).then((res) => res.data),
  );

  const dosingUnits = orderConfig?.drugDosingUnits || [];
  const drugRoutes = orderConfig?.drugRoutes || [];

  // We set up two forms since they have very different requirements and validation
  const {
    register: regMed,
    control: ctrlMed,
    handleSubmit: handleMedSubmit,
    formState: { errors: medErrors, isSubmitting: isMedSubmitting, isValid: isMedValid },
    reset: resetMed,
    setValue: setMedValue,
  } = useForm<MedicationFormValues>({
    resolver: zodResolver(medicationSchema),
    defaultValues: { route: '' },
    mode: 'all',
  });

  const {
    register: regNonMed,
    handleSubmit: handleNonMedSubmit,
    formState: { errors: nonMedErrors, isSubmitting: isNonMedSubmitting, isValid: isNonMedValid },
    reset: resetNonMed,
  } = useForm<NonMedicationFormValues>({
    resolver: zodResolver(nonMedicationSchema),
    mode: 'all',
  });

  // --- Submission for Medication Tab -----------------------
  const onMedicationSubmit = useCallback(
    async (values: MedicationFormValues) => {
      try {
        // Build the timestamp (as epoch in seconds to align with backend expectations)
        const completeDate = new Date(values.adminDate);
        const [hours, minutes] = values.adminTime.split(':').map(Number);
        completeDate.setHours(hours, minutes, 0, 0);

        // Fallback provider UUID if none available in session
        const currentProviderUuid = session?.currentProvider?.uuid || 'd7a67c17-5e07-11ef-8f7c-0242ac120002';

        // payload /ipd/adhocMedicationAdministrations
        const payload = {
          patientUuid: patientUuid,
          drugUuid: values.drugUuid,
          dose: values.dose,
          doseUnits: values.doseUnits,
          route: values.route,
          providers: [
            {
              providerUuid: currentProviderUuid,
              function: 'Performer'
            },
            {
              providerUuid: values.provider,
              function: 'Witness'
            }
          ],
          notes: values.notes ? [
            {
              authorUuid: currentProviderUuid,
              text: values.notes
            }
          ] : [],
          status: 'completed',
          administeredDateTime: Math.floor(completeDate.getTime() / 1000), // convert to seconds
        };

        await createAdhocMedicationAdministration(payload);

        showSnackbar({
          title: t('emergencyTaskSaved', 'Emergency task logged'),
          kind: 'success',
          isLowContrast: true,
        });

        mutateTaskList();
        window.dispatchEvent(new CustomEvent('ipd:medication-refresh'));
        closeWorkspace();
      } catch (err) {
        showSnackbar({
          title: t('taskSaveError', 'Failed to log Emergency medication.'),
          subtitle: err instanceof Error ? err.message : String(err),
          kind: 'error',
        });
      }
    },
    [patientUuid, mutateTaskList, t],
  );

  // --- Submission for Non-Medication Tab -----------------------
  const onNonMedicationSubmit = useCallback(
    async (values: NonMedicationFormValues) => {
      try {
        // For standard task creation
        const scheduleDate = new Date();
        const [hours, minutes] = values.scheduleTime.split(':').map(Number);
        scheduleDate.setHours(hours, minutes, 0, 0);

        await createNursingTask({
          name: values.taskName,
          intent: 'ORDER',
          status: 'REQUESTED',
          priority: 'routine',
          patient: { uuid: patientUuid },
          taskType: values.taskType ? { uuid: values.taskType } : { uuid: config.concepts.defaultNursingTaskTypeUuid },
          executionPeriod: { start: scheduleDate.toISOString() },
        });

        showSnackbar({
          title: t('taskSaved', 'Task requested successfully'),
          kind: 'success',
          isLowContrast: true,
        });

        mutateTaskList();
        window.dispatchEvent(new CustomEvent('ipd:medication-refresh'));
        closeWorkspace();
      } catch (err) {
        showSnackbar({
          title: t('taskSaveError', 'Failed to request task'),
          subtitle: err instanceof Error ? err.message : String(err),
          kind: 'error',
        });
      }
    },
    [patientUuid, mutateTaskList, t],
  );

  const handleCancel = useCallback(() => {
    closeWorkspace();
  }, [closeWorkspace]);

  return (
    <Workspace2 title={t('addNursingTask', 'Add Nursing Task')}>
      <div className={styles.workspaceLayout}>
      <Tabs
        selectedIndex={activeTab === 'medication' ? 0 : 1}
        onChange={(idx) => setActiveTab(idx.selectedIndex === 0 ? 'medication' : 'non-medication')}
      >
        <TabList aria-label="Add Task Tabs">
          <Tab>{t('medication', 'Medication')}</Tab>
          <Tab>{t('nonMedication', 'Non-Medication')}</Tab>
        </TabList>

        <TabPanels>
          {/* Tab 1: Medication */}
          <TabPanel>
            <Form id="med-task-form" onSubmit={handleMedSubmit(onMedicationSubmit)}>
              <Stack gap={6}>
                <Controller
                  name="drugUuid"
                  control={ctrlMed}
                  render={({ field }) => (
                    <ComboBox
                      id="drug-search"
                      titleText={
                        <>
                          {t('drugName', 'Drug Name (Search Drug)')}
                          <span className={styles.requiredIndicator}>*</span>
                        </>
                      }
                      placeholder="e.g. Paracetamol"
                      items={drugs || []}
                      itemToString={(item) => (item ? item.display : '')}
                      onChange={({ selectedItem }) => {
                        field.onChange(selectedItem?.uuid || '');
                        if (selectedItem) {
                          if (selectedItem.dosageForm?.display) {
                            const matchingUnit = dosingUnits.find(
                              (u: any) => u.display?.toLowerCase() === selectedItem.dosageForm.display.toLowerCase(),
                            );
                            setMedValue('doseUnits', matchingUnit?.uuid || selectedItem.dosageForm.display);
                          }
                        }
                      }}
                      onInputChange={(inputValue) => setDrugSearchText(inputValue)}
                      invalid={!!medErrors.drugUuid}
                      invalidText={medErrors.drugUuid?.message as string}
                    />
                  )}
                />

                <div style={{ display: 'flex', gap: '1rem' }}>
                  <TextInput
                    id="dose"
                    type="number"
                    labelText={
                      <>
                        {t('dose', 'Dose')}
                        <span className={styles.requiredIndicator}>*</span>
                      </>
                    }
                    placeholder="e.g. 500"
                    invalid={!!medErrors.dose}
                    invalidText={medErrors.dose?.message}
                    {...regMed('dose')}
                  />
                  <Select
                    id="doseUnits"
                    labelText={
                      <>
                        {t('doseUnits', 'Unit')}
                        <span className={styles.requiredIndicator}>*</span>
                      </>
                    }
                    invalid={!!medErrors.doseUnits}
                    invalidText={medErrors.doseUnits?.message}
                    {...(regMed('doseUnits') as any)}
                  >
                    <SelectItem value="" text={t('selectUnit', 'Select Unit')} disabled />
                    {dosingUnits.map((unit: any) => (
                      <SelectItem key={unit.uuid} value={unit.uuid} text={unit.display} />
                    ))}
                  </Select>
                  <Select
                    id="route"
                    labelText={
                      <>
                        {t('route', 'Route')}
                        <span className={styles.requiredIndicator}>*</span>
                      </>
                    }
                    invalid={!!medErrors.route}
                    invalidText={medErrors.route?.message}
                    {...(regMed('route') as any)}
                  >
                    <SelectItem value="" text={t('selectRoute', 'Select Route')} disabled />
                    {drugRoutes.map((route: any) => (
                      <SelectItem key={route.uuid} value={route.uuid} text={route.display} />
                    ))}
                  </Select>
                </div>

                <div style={{ display: 'flex', gap: '1rem' }}>
                  <Controller
                    name="adminDate"
                    control={ctrlMed}
                    render={({ field }) => (
                      <OpenmrsDatePicker
                        labelText={
                          <>
                            {t('adminDate', 'Administration Date')}
                            <span className={styles.requiredIndicator}>*</span>
                          </>
                        }
                        value={field.value}
                        maxDate={new Date()}
                        onChange={(date) => field.onChange(date ?? undefined)}
                        invalid={!!medErrors.adminDate}
                        invalidText={medErrors.adminDate?.message}
                      />
                    )}
                  />
                  <TextInput
                    id="admin-time"
                    type="time"
                    labelText={
                      <>
                        {t('adminTime', 'Administration Time')}
                        <span className={styles.requiredIndicator}>*</span>
                      </>
                    }
                    invalid={!!medErrors.adminTime}
                    invalidText={medErrors.adminTime?.message}
                    {...regMed('adminTime')}
                  />
                </div>

                <Select
                  id="provider"
                  labelText={
                    <>
                      {t('provider', 'Acknowledgement Requested From')}
                      <span className={styles.requiredIndicator}>*</span>
                    </>
                  }
                  invalid={!!medErrors.provider}
                  invalidText={medErrors.provider?.message}
                  {...(regMed('provider') as any)}
                  defaultValue=""
                >
                  <SelectItem value="" text="Select Provider" disabled />
                  {providers?.map((provider) => (
                    <SelectItem key={provider.uuid} value={provider.uuid} text={provider.person.display} />
                  ))}
                </Select>

                <TextArea
                  id="notes"
                  labelText={
                    <>
                      {t('notes', 'Notes')}
                      <span className={styles.requiredIndicator}>*</span>
                    </>
                  }
                  placeholder={'Enter a maximum of 250 characters'}
                  rows={4}
                  invalid={!!medErrors.notes}
                  invalidText={medErrors.notes?.message}
                  {...regMed('notes')}
                />
              </Stack>
            </Form>
          </TabPanel>

          {/* Tab 2: Non-Medication */}
          <TabPanel>
            <Form id="non-med-task-form" onSubmit={handleNonMedSubmit(onNonMedicationSubmit)}>
              <Stack gap={6}>
                <TextArea
                  id="task-name"
                  labelText={
                    <>
                      {t('taskName', 'Task Name')}
                      <span className={styles.requiredIndicator}>*</span>
                    </>
                  }
                  placeholder="Enter a title for the task"
                  rows={2}
                  invalid={!!nonMedErrors.taskName}
                  invalidText={nonMedErrors.taskName?.message}
                  {...regNonMed('taskName')}
                />

                <Select
                  id="task-type"
                  labelText={t('taskType', 'Task Type')}
                  {...(regNonMed('taskType') as any)}
                  defaultValue=""
                >
                  <SelectItem value="" text={t('selectTaskType', 'Select Task Type')} disabled />
                  {taskTypes.map((type: any) => (
                    <SelectItem key={type.uuid} value={type.uuid} text={type.display} />
                  ))}
                </Select>

                <TextInput
                  id="schedule-time"
                  type="time"
                  labelText={
                    <>
                      {t('scheduleTime', 'Schedule Time')}
                      <span className={styles.requiredIndicator}>*</span>
                    </>
                  }
                  invalid={!!nonMedErrors.scheduleTime}
                  invalidText={nonMedErrors.scheduleTime?.message}
                  {...regNonMed('scheduleTime')}
                />
              </Stack>
            </Form>
          </TabPanel>
        </TabPanels>
      </Tabs>

      <ButtonSet className={styles.buttonSet}>
        <Button kind="secondary" onClick={handleCancel} disabled={isMedSubmitting || isNonMedSubmitting}>
          {t('cancel', 'Cancel')}
        </Button>
        <Button
          kind="primary"
          type="submit"
          form={activeTab === 'medication' ? 'med-task-form' : 'non-med-task-form'}
          disabled={activeTab === 'medication' ? isMedSubmitting || !isMedValid : isNonMedSubmitting || !isNonMedValid}
        >
          {(activeTab === 'medication' ? isMedSubmitting : isNonMedSubmitting)
            ? t('saving', 'Saving…')
            : t('saveTask', 'Save')}
        </Button>
      </ButtonSet>
      </div>
    </Workspace2>
  );
};

export default NursingTaskFormWorkspace;
