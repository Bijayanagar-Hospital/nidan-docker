import useSWR from 'swr';
import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import { fetchMedicationTasks } from './nursing-tasks-resource';
import type { NursingTask, RestApiResult } from '../../types';

export function useAdvancedNursingTasks(
  patientUuid: string | undefined,
  visitUuid: string | undefined,
  startTime: number,
  endTime: number,
  status?: string,
) {
  let tasksUrl = patientUuid ? `${restBaseUrl}/ipd/tasks?patient=${patientUuid}` : null;

  if (tasksUrl && status) {
    tasksUrl += `&status=${status}`;
  }

  const { data: nonMedTasksData, error: nonMedError, isLoading: nonMedLoading, mutate: mutateNonMed } = useSWR<
    FetchResponse<RestApiResult<NursingTask>>,
    Error
  >(tasksUrl, openmrsFetch);

  // For medications, we trigger via a unique SWR key composed of the boundaries
  const medKey = (patientUuid && visitUuid)
    ? ['medication-tasks', patientUuid, visitUuid, startTime, endTime]
    : null;

  const { data: medTasksData, error: medError, isLoading: medLoading, mutate: mutateMed } = useSWR(
    medKey,
    () => fetchMedicationTasks(patientUuid!, Math.floor(startTime / 1000), Math.floor(endTime / 1000), visitUuid!)
  );

  const mutateAll = () => {
    mutateNonMed();
    mutateMed();
  };

  return {
    nonMedicationTasks: nonMedTasksData?.data?.results ?? [],
    medicationTasks: medTasksData ?? [],
    isLoading: nonMedLoading || medLoading,
    error: nonMedError || medError || null,
    mutateAll,
  };
}

