import dayjs from 'dayjs';

/**
 * Checks if the actual administration time is within the "late window"
 * of the scheduled start time.
 *
 * @param scheduledTime The ISO string or Date of the scheduled task
 * @param actualTime The HH:mm string from the time picker
 * @param lateWindowMinutes Configurable window (default 60)
 * @returns true if the task was administered within the window
 */
export function isTimeWithinLateWindow(
  scheduledTime: string | Date,
  actualTime: string,
  lateWindowMinutes: number,
): boolean {
  if (!actualTime) return true;

  const scheduled = dayjs(scheduledTime);
  const [hours, minutes] = actualTime.split(':').map(Number);
  
  // Create actual date by combining scheduled date and actual time
  const actual = dayjs(scheduledTime)
    .set('hour', hours)
    .set('minute', minutes)
    .set('second', 0)
    .set('millisecond', 0);

  // If actual time is earlier than scheduled (same day), it's within the window (early).
  // If it's more than `lateWindowMinutes` after scheduled, it's NOT within the window.
  const diffInMinutes = actual.diff(scheduled, 'minutes');
  
  return diffInMinutes <= lateWindowMinutes;
}

/**
 * Checks if a given time (HH:mm) is in the future relative to the current time.
 */
export function isFutureTime(timeStr: string): boolean {
  if (!timeStr) return false;
  
  const [hours, minutes] = timeStr.split(':').map(Number);
  const now = dayjs();
  const target = dayjs().set('hour', hours).set('minute', minutes).set('second', 0).set('millisecond', 0);
  
  return target.isAfter(now);
}

export { resolveDisplayName } from '../../utils/display';
