import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  DataTable,
  OverflowMenu,
  OverflowMenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
  DataTableSkeleton,
} from '@carbon/react';
import { Add } from '@carbon/react/icons';
import { launchWorkspace, showSnackbar } from '@openmrs/esm-framework';
import { updateNursingTask } from './nursing-tasks-resource';
import { useNursingTasks } from '../patient-ipd/use-ipd-patient';
import { publishAuditEvent } from '../../utils/audit-event';
import type { NursingTask } from '../../types';
import styles from './nursing-tasks.scss';

const STATUS_TAG_TYPE: Record<NursingTask['status'], 'blue' | 'green' | 'red' | 'gray'> = {
  REQUESTED: 'blue',
  IN_PROGRESS: 'green',
  COMPLETED: 'gray',
  CANCELLED: 'red',
};

const HEADERS = [
  { key: 'name', header: 'Task' },
  { key: 'priority', header: 'Priority' },
  { key: 'status', header: 'Status' },
  { key: 'dueDate', header: 'Due' },
  { key: 'actions', header: '' },
];

interface NursingTasksProps {
  patientUuid: string;
  visitUuid: string;
}

/**
 * NursingTasks — IPD-02
 *
 * Full-featured nursing task list with:
 * - Sortable DataTable (name, priority, status, due date)
 * - Inline status transition via overflow menu (Start / Complete / Cancel)
 * - "Add Task" button → launchWorkspace
 * - mutate() passed into workspace so list auto-refreshes on save
 *
 * Migration note: replaces NursingTasks.jsx (plain unordered list)
 * and its manual accordion-based add form.
 */
const NursingTasks: React.FC<NursingTasksProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const { tasks, isLoading, mutate } = useNursingTasks(patientUuid);

  const handleAddTask = useCallback(() => {
    launchWorkspace('add-ipd-task', { patientUuid, visitUuid, mutateTaskList: mutate });
    publishAuditEvent('VIEWED_NURSING_TASK_FORM', patientUuid, visitUuid);
  }, [patientUuid, visitUuid, mutate]);

  const handleTransition = useCallback(
    async (task: NursingTask, newStatus: NursingTask['status']) => {
      try {
        await updateNursingTask(task.uuid, { status: newStatus });
        mutate();
        showSnackbar({
          title: t('taskUpdated', 'Task updated'),
          kind: 'success',
          isLowContrast: true,
        });
      } catch (err) {
        showSnackbar({
          title: t('taskUpdateError', 'Failed to update task'),
          subtitle: err instanceof Error ? err.message : String(err),
          kind: 'error',
        });
      }
    },
    [mutate, t],
  );

  if (isLoading) {
    return <DataTableSkeleton columnCount={HEADERS.length} rowCount={5} />;
  }

  const rows = tasks.map((task) => ({
    id: task.uuid,
    name: task.name,
    priority: task.intent,
    status: (
      <Tag type={STATUS_TAG_TYPE[task.status]} size="sm">
        {t(task.status, task.status)}
      </Tag>
    ),
    dueDate: task.executionPeriod?.start
      ? new Date(task.executionPeriod.start).toLocaleDateString()
      : '—',
    actions: (
      <OverflowMenu size="sm" flipped>
        {task.status === 'REQUESTED' && (
          <OverflowMenuItem
            itemText={t('startTask', 'Start')}
            onClick={() => handleTransition(task, 'IN_PROGRESS')}
          />
        )}
        {task.status === 'IN_PROGRESS' && (
          <OverflowMenuItem
            itemText={t('completeTask', 'Complete')}
            onClick={() => handleTransition(task, 'COMPLETED')}
          />
        )}
        {(task.status === 'REQUESTED' || task.status === 'IN_PROGRESS') && (
          <OverflowMenuItem
            itemText={t('cancelTask', 'Cancel')}
            isDelete
            onClick={() => handleTransition(task, 'CANCELLED')}
          />
        )}
      </OverflowMenu>
    ),
  }));

  return (
    <div className={styles.nursingTasks}>
      <div className={styles.header}>
        <Button kind="ghost" size="sm" renderIcon={Add} onClick={handleAddTask}>
          {t('addTask', 'Add Task')}
        </Button>
      </div>

      {tasks.length === 0 ? (
        <p className={styles.empty}>{t('noTasks', 'No active nursing tasks')}</p>
      ) : (
        <DataTable rows={rows} headers={HEADERS} isSortable size="sm">
          {({ rows: tableRows, headers, getTableProps, getHeaderProps, getRowProps }) => (
            <TableContainer>
              <Table {...getTableProps()}>
                <TableHead>
                  <TableRow>
                    {headers.map((h) => {
                      const { onClick, ...rest } = getHeaderProps({ header: h });
                      return (
                        <TableHeader
                          key={h.key}
                          {...rest}
                          onClick={onClick as unknown as React.MouseEventHandler<HTMLButtonElement>}
                        >
                          {h.header}
                        </TableHeader>
                      );
                    })}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {tableRows.map((row) => (
                    <TableRow {...getRowProps({ row })} key={row.id}>
                      {row.cells.map((cell) => (
                        <TableCell key={cell.id}>{cell.value}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DataTable>
      )}
    </div>
  );
};

export default NursingTasks;
