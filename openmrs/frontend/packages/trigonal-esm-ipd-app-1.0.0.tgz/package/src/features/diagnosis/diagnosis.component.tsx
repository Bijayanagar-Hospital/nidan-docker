import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import classNames from 'classnames';
import {
  DataTable,
  DataTableSkeleton,
  InlineNotification,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableExpandHeader,
  TableExpandRow,
  TableExpandedRow,
  TableHead,
  TableHeader,
  TableRow,
} from '@carbon/react';
import { formatDate, parseDate, usePagination } from '@openmrs/esm-framework';
import { PatientChartPagination } from '@openmrs/esm-patient-common-lib';
import { usePatientDiagnoses } from './use-patient-diagnoses';
import { resolveDisplayName } from '../../utils/display';
import styles from './diagnosis.scss';

interface DiagnosisProps {
  patientUuid: string;
}

const PAGE_SIZE = 5;

const Diagnosis: React.FC<DiagnosisProps> = ({ patientUuid }) => {
  const { t } = useTranslation();
  const { diagnoses, isLoading, error } = usePatientDiagnoses(patientUuid);

  // Pagination hook from the ESM Framework
  const { results: paginatedDiagnoses, goTo, currentPage } = usePagination(diagnoses, PAGE_SIZE);

  const tableHeaders = [
    { key: 'date', header: t('date', 'Date') },
    { key: 'diagnosisName', header: t('diagnosis', 'Diagnosis') },
    { key: 'certainty', header: t('certainty', 'Certainty') },
  ];

  const tableRows = useMemo(
    () =>
      paginatedDiagnoses.map((diag) => {
        // Extract display name or free text
        const display =
          resolveDisplayName(diag.diagnosis?.codedAnswer?.name) ||
          resolveDisplayName(diag.diagnosis?.display) ||
          resolveDisplayName(diag.diagnosis?.freeTextAnswer) ||
          t('unknownDiagnosis', 'Unknown Diagnosis');

        // Extract date from either diagnosisDateTime or parent encounter
        const rawDate = diag.diagnosisDateTime || diag.encounter?.encounterDatetime;
        const formattedDate = rawDate ? formatDate(parseDate(rawDate), { mode: 'wide' }) : '—';

        return {
          id: diag.uuid,
          date: formattedDate,
          diagnosisName: display,
          certainty: resolveDisplayName(diag.certainty) || '—',
          // Raw fields for the expanded view
          order: resolveDisplayName(diag.order) ?? '—',
          status: resolveDisplayName(diag.status) ?? '—',
        };
      }),
    [paginatedDiagnoses, t],
  );

  if (isLoading) {
    return <DataTableSkeleton columnCount={3} rowCount={4} zebra />;
  }

  if (error) {
    return (
      <InlineNotification kind="error" title={t('error', 'Error loading diagnoses')} subtitle={error.message} />
    );
  }

  if (!diagnoses || diagnoses.length === 0) {
    return <p className={styles.emptyState}>{t('noDiagnoses', 'No diagnoses active for this patient.')}</p>;
  }

  return (
    <>
      <DataTable rows={tableRows} headers={tableHeaders} isSortable size="sm" useZebraStyles>
        {({
          getExpandedRowProps,
          getExpandHeaderProps,
          getHeaderProps,
          getRowProps,
          getTableContainerProps,
          getTableProps,
          headers,
          rows,
        }) => (
          <TableContainer {...getTableContainerProps()}>
            <Table {...getTableProps()}>
              <TableHead>
                <TableRow>
                  <TableExpandHeader enableToggle aria-controls="diagnosis-table-body" {...(getExpandHeaderProps() as any)} />
                  {headers.map((header, i) => {
                    const { onClick, ...restHeaderProps } = getHeaderProps({ header });
                    return (
                      <TableHeader
                        {...restHeaderProps}
                        onClick={onClick as unknown as React.MouseEventHandler<HTMLButtonElement>}
                      >
                        {header.header}
                      </TableHeader>
                    );
                  })}
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row) => (
                  <React.Fragment key={row.id}>
                    <TableExpandRow aria-controls={`row-${row.id}`} {...(getRowProps({ row }) as any)}>
                      {row.cells.map((cell) => (
                        <TableCell key={cell.id}>{cell.value}</TableCell>
                      ))}
                    </TableExpandRow>
                    {row.isExpanded ? (
                      <TableExpandedRow
                        className={styles.expandedRow}
                        colSpan={headers.length + 1}
                        {...getExpandedRowProps({ row })}
                      >
                        <div className={styles.expandedContainer}>
                          <div className={styles.copy}>
                            <p className={styles.metadata}>
                              <strong>{t('diagnosisRank', 'Rank / Order')}:</strong>{' '}
                              {tableRows.find((r) => r.id === row.id)?.order ?? '—'}
                            </p>
                            <p className={styles.metadata}>
                              <strong>{t('diagnosisStatus', 'Status')}:</strong>{' '}
                              {tableRows.find((r) => r.id === row.id)?.status ?? '—'}
                            </p>
                          </div>
                        </div>
                      </TableExpandedRow>
                    ) : (
                      <TableExpandedRow className={styles.hiddenRow} colSpan={headers.length + 1} />
                    )}
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </DataTable>

      {diagnoses.length > PAGE_SIZE && (
        <PatientChartPagination
          pageNumber={currentPage}
          totalItems={diagnoses.length}
          currentItems={paginatedDiagnoses.length}
          pageSize={PAGE_SIZE}
          onPageNumberChange={({ page }: { page: number }) => goTo(page)}
          dashboardLinkUrl=""
          dashboardLinkLabel=""
        />
      )}
    </>
  );
};

export default Diagnosis;
