import React, { Suspense, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Accordion,
  AccordionItem,
  DataTableSkeleton,
  InlineNotification,
  SkeletonText,
} from '@carbon/react';
import HospitalBed from '@carbon/icons-react/es/HospitalBed';
import {
  ExtensionSlot,
  launchWorkspace,
  useConfig,
  usePatient,
  useVisit,
} from '@openmrs/esm-framework';
import Allergies from '../allergies/allergies.component';
import DrugChart from '../drug-chart/drug-chart.component';
import NursingTasks from '../nursing-tasks/nursing-tasks.component';
import Vitals from '../vitals/vitals.component';
import { useMedicationSchedule } from './use-ipd-patient';
import { publishAuditEvent } from '../../utils/audit-event';
import type { IpdConfig } from '../../config-schema';
import { componentKeys } from '../../constants';
import styles from './patient-ipd-dashboard.scss';

/**
 * PatientIpdDashboard — per-patient IPD view rendered inside the O3 patient chart.
 *
 * Rendered as an O3 *extension* in `patient-ipd-slot`. Extensions run in a
 * separate React tree with no `<Router>` context, so `useParams()` would
 * always return `{}`. `usePatient()` is called without an argument so it
 * falls back to its internal `getPatientUuidFromUrl()` helper, which reads
 * the UUID from `window.location.pathname` (`/patient/{uuid}/…`).
 */
const PatientIpdDashboard: React.FC = () => {
  const { t } = useTranslation();

  const config = useConfig<IpdConfig>();
  const {
    patient,
    patientUuid: patientUuidFromHook,
    isLoading: patientLoading,
  } = usePatient();
  const patientUuid = patientUuidFromHook ?? '';
  const { currentVisit, isLoading: visitLoading } = useVisit(patientUuid);

  const visitUuid = currentVisit?.uuid;

  const { medicationSchedules, isLoading: medsLoading, mutate: mutateMeds } =
    useMedicationSchedule(visitUuid);

  const handleAddMedication = useCallback(() => {
    launchWorkspace('add-ipd-medication', { patientUuid, visitUuid });
    publishAuditEvent('OPENED_ADD_MEDICATION', patientUuid, visitUuid);
  }, [patientUuid, visitUuid]);

  // Publish ward-level audit on mount
  React.useEffect(() => {
    if (patientUuid && visitUuid) {
      publishAuditEvent('VIEWED_PATIENT_IPD_DASHBOARD', patientUuid, visitUuid);
    }
  }, [patientUuid, visitUuid]);

  if (patientLoading || visitLoading) {
    return (
      <div className={styles.skeleton}>
        <SkeletonText heading paragraph lineCount={4} />
      </div>
    );
  }

  if (!patient) {
    return (
      <InlineNotification
        kind="error"
        title={t('patientNotFound', 'Patient not found')}
        subtitle={t('patientNotFoundMsg', 'Could not load patient data for UUID: {{uuid}}', {
          uuid: patientUuid,
        })}
      />
    );
  }

  if (!visitUuid) {
    return (
      <InlineNotification
        kind="warning"
        title={t('noActiveVisit', 'No active visit')}
        subtitle={t('noActiveVisitMsg', 'This patient has no active inpatient visit.')}
      />
    );
  }

  const sections = config.ipdDashboardSections
    .slice()
    .sort((a, b) => a.displayOrder - b.displayOrder);

  return (
    <main className={styles.ipdPage}>
      {/* ── Page header ─────────────────────────────────────────────── */}
      <header className={styles.pageHeader}>
        <HospitalBed size={20} className={styles.pageHeaderIcon} />
        <h4 className={styles.pageHeaderTitle}>{t('ipdSummary', 'IPD Summary')}</h4>
      </header>

      {/* ── Bed assignment banner (IPD-05) ─────────────────────────── */}
      <section className={styles.bannerSection}>
        <ExtensionSlot
          name="patient-ipd-banner-slot"
          state={{ patientUuid, visitUuid }}
        />
      </section>

      {/* ── Configurable section accordion ─────────────────────────── */}
      <section className={styles.sectionsContainer}>
        <Accordion>
          {sections.map((sec) => {
            switch (sec.componentKey) {
              case componentKeys.ALLERGIES:
                return (
                  <AccordionItem key={sec.componentKey} title={t('allergies', sec.title)} open>
                    {/* IPD-03 */}
                    <Allergies patientUuid={patientUuid ?? ''} />
                  </AccordionItem>
                );

              case componentKeys.VITALS:
                return (
                  <AccordionItem key={sec.componentKey} title={t('vitals', sec.title)} open>
                    {/* IPD-04 */}
                    <Vitals patientUuid={patientUuid ?? ''} visitUuid={visitUuid} />
                  </AccordionItem>
                );

              case componentKeys.NURSING_TASKS:
                return config.showNursingTasks ? (
                  <AccordionItem key={sec.componentKey} title={t('nursingTasks', sec.title)} open>
                    {/* IPD-02 */}
                    <NursingTasks patientUuid={patientUuid ?? ''} visitUuid={visitUuid} />
                  </AccordionItem>
                ) : null;

              case componentKeys.DRUG_CHART:
                return config.showMedicationChart ? (
                  <AccordionItem key={sec.componentKey} title={t('drugChart', sec.title)} open>
                    {/* IPD-01 */}
                    <Suspense fallback={<DataTableSkeleton columnCount={26} rowCount={4} />}>
                      <DrugChart
                        schedules={medicationSchedules}
                        patientUuid={patientUuid ?? ''}
                        visitUuid={visitUuid}
                        isLoading={medsLoading}
                        onAddMedication={handleAddMedication}
                      />
                    </Suspense>
                  </AccordionItem>
                ) : null;

              default:
                /**
                 * Unknown keys (DG, TR, IO, etc.) are delegated to ExtensionSlots
                 * so other installed ESMs can contribute sections without modifying
                 * this module.
                 */
                return (
                  <AccordionItem key={sec.componentKey} title={t(sec.componentKey, sec.title)} open>
                    <ExtensionSlot
                      name={`ipd-${sec.componentKey.toLowerCase()}-slot`}
                      state={{ patientUuid, visitUuid, config: sec.config }}
                    />
                  </AccordionItem>
                );
            }
          })}
        </Accordion>
      </section>
    </main>
  );
};

export default PatientIpdDashboard;
