import useSWR from 'swr';
import { openmrsFetch, fhirBaseUrl, restBaseUrl } from '@openmrs/esm-framework';
import type {
  MedicationSchedule,
  NursingTask,
  RestApiResult,
} from '../../types';

/**
 * Fetches all scheduled medication slots for a patient visit.
 *
 * Migration note: replaces `axios.get(ALL_DRUG_ORDERS_URL(visitUuid))`
 * called imperatively in Dashboard.jsx.
 *
 * Endpoint: GET /ws/rest/v1/ipdVisit/{visitUuid}/medication?includes=emergencyMedications
 */
export function useMedicationSchedule(visitUuid: string | undefined) {
  const url = visitUuid
    ? `${restBaseUrl}/ipdVisit/${visitUuid}/medication?includes=emergencyMedications`
    : null;

  const { data, error, isLoading, mutate } = useSWR<{ results: MedicationSchedule[] }, Error>(
    url,
    (u: string) => openmrsFetch<{ results: MedicationSchedule[] }>(u).then((r) => r.data),
  );

  return {
    medicationSchedules: data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}

/**
 * Fetches nursing tasks for a patient visit.
 *
 * Migration note: replaces `axios.get(NON_MEDICATION_BASE_URL)` with patient filter.
 *
 * Endpoint: GET /ws/rest/v1/tasks?patient={patientUuid}&status=REQUESTED,IN_PROGRESS
 */
export function useNursingTasks(patientUuid: string | undefined) {
  const url = patientUuid
    ? `${restBaseUrl}/tasks?patient=${patientUuid}&status=REQUESTED,IN_PROGRESS`
    : null;

  const { data, error, isLoading, mutate } = useSWR<RestApiResult<NursingTask>, Error>(
    url,
    (u: string) => openmrsFetch<RestApiResult<NursingTask>>(u).then((r) => r.data),
  );

  return {
    tasks: data?.results ?? [],
    isLoading,
    error,
    mutate,
  };
}

/** FHIR R4 AllergyIntolerance resource — minimal subset used in the UI */
export interface FhirAllergyIntolerance {
  id: string;
  resourceType: 'AllergyIntolerance';
  clinicalStatus?: {
    coding: Array<{ code: string; display?: string }>;
  };
  verificationStatus?: {
    coding: Array<{ code: string; display?: string }>;
  };
  category?: string[];
  criticality?: 'low' | 'high' | 'unable-to-assess';
  code?: {
    coding: Array<{ code: string; display?: string; system?: string }>;
    text?: string;
  };
  patient: { reference: string; display?: string };
  onsetDateTime?: string;
  reaction?: Array<{
    substance?: { coding: Array<{ display?: string }>; text?: string };
    manifestation: Array<{ coding: Array<{ display?: string }>; text?: string }>;
    severity?: 'mild' | 'moderate' | 'severe';
    onset?: string;
  }>;
  note?: Array<{ text: string }>;
}

/**
 * Fetches FHIR AllergyIntolerance resources for a patient.
 *
 * Migration note: replaces `axios.get(ALLERGIES_BASE_URL + "?patient=" + uuid)`.
 * Uses the `fhirBaseUrl` constant from @openmrs/esm-framework which automatically
 * resolves to the correct FHIR R4 endpoint regardless of deployment path.
 */
export function usePatientAllergies(patientUuid: string | undefined) {
  const url = patientUuid
    ? `${fhirBaseUrl}/AllergyIntolerance?patient=${patientUuid}&_sort=-date`
    : null;

  type AllergyBundle = { entry?: Array<{ resource: FhirAllergyIntolerance }> };
  const { data, error, isLoading } = useSWR<AllergyBundle, Error>(
    url,
    (u: string) => openmrsFetch<AllergyBundle>(u).then((r) => r.data),
  );

  return {
    allergies: data?.entry?.map((e) => e.resource) ?? [],
    isLoading,
    error,
  };
}

/**
 * Fetches the bed assignment for a patient visit.
 *
 * Endpoint: GET /ws/rest/v1/beds?patientUuid={uuid}
 */
export function usePatientBed(patientUuid: string | undefined) {
  const url = patientUuid ? `${restBaseUrl}/beds?patientUuid=${patientUuid}` : null;

  const { data, isLoading, mutate } = useSWR<RestApiResult<unknown>, Error>(
    url,
    (u: string) => openmrsFetch<RestApiResult<unknown>>(u).then((r) => r.data),
  );

  return {
    bed: data?.results?.[0] ?? null,
    isLoading,
    mutate,
  };
}
