import dayjs from 'dayjs';
import type { MedicationSchedule } from '../../types';

// Anchor dummy dates exactly to today so they appear on the active daily grid.
const today = dayjs().startOf('day');

export const MOCK_MEDICATION_SCHEDULES = [
  {
    uuid: 'mock-sched-1',
    drug: { name: 'Amoxicillin' },
    dose: 500,
    doseUnits: { display: 'mg' },
    route: { display: 'Oral' },
    frequency: { display: '1x/day' },
    slots: [
      {
        uuid: 'slot-1-1',
        status: 'COMPLETED',
        scheduledDate: today.hour(10).minute(0).toISOString(),
        administeredDateTime: today.hour(10).minute(15).toISOString(),
        administeredBy: { display: 'Nurse Joy' },
      },
      {
        uuid: 'slot-1-2',
        status: 'SCHEDULED',
        scheduledDate: today.add(1, 'day').hour(10).minute(0).toISOString(),
      },
    ],
  },
  {
    uuid: 'mock-sched-2',
    drug: { name: 'Ibuprofen' },
    dose: 200,
    doseUnits: { display: 'mg' },
    route: { display: 'Oral' },
    frequency: { display: '2x/day' },
    slots: [
      // {
      //   uuid: 'slot-2-1',
      //   status: 'ADMINISTERED_LATE',
      //   scheduledDate: today.hour(8).minute(0).toISOString(),
      //   administeredDateTime: today.hour(11).minute(30).toISOString(), // late
      //   administeredBy: { display: 'Dr. Hibbert' },
      // },
      {
        uuid: 'slot-2-3',
        status: 'SCHEDULED',
        scheduledDate: today.hour(20).minute(30).toISOString(),
      },
    ],
  },
  {
    uuid: 'mock-sched-1',
    drug: { name: 'Amoxicillin' },
    dose: 500,
    doseUnits: { display: 'mg' },
    route: { display: 'Oral' },
    frequency: { display: '1x/day' },
    slots: [
      {
        uuid: 'slot-1-1',
        status: 'COMPLETED',
        scheduledDate: today.hour(10).minute(0).toISOString(),
        administeredDateTime: today.hour(10).minute(15).toISOString(),
        administeredBy: { display: 'Nurse Joy' },
      },
      {
        uuid: 'slot-1-2',
        status: 'SCHEDULED',
        scheduledDate: today.add(1, 'day').hour(10).minute(0).toISOString(),
      },
    ],
  },
  {
    uuid: 'mock-sched-4',
    drug: { name: 'Ibuprofenn' },
    dose: 200,
    doseUnits: { display: 'mg' },
    route: { display: 'Oral' },
    frequency: { display: '2x/day' },
    slots: [
      // {
      //   uuid: 'slot-2-1',
      //   status: 'ADMINISTERED_LATE',
      //   scheduledDate: today.hour(8).minute(0).toISOString(),
      //   administeredDateTime: today.hour(11).minute(30).toISOString(), // late
      //   administeredBy: { display: 'Dr. Hibbert' },
      // },
      {
        uuid: 'slot-2-3',
        status: 'SCHEDULED',
        scheduledDate: today.hour(20).minute(30).toISOString(),
      },
    ],
  },
  {
    uuid: 'mock-sched-5',
    drug: { name: 'Paracetamoll' },
    dose: 1000,
    doseUnits: { display: 'mg' },
    route: { display: 'IV' },
    frequency: { display: 'Every 6 hours' },
    slots: [
      {
        uuid: 'slot-3-1',
        status: 'ADMINISTERED',
        scheduledDate: today.hour(6).minute(0).toISOString(),
        administeredDateTime: today.hour(6).minute(0).toISOString(),
        administeredBy: { display: 'Nurse Joy' },
      },
      {
        uuid: 'slot-3-2',
        status: 'COMPLETED',
        scheduledDate: today.hour(12).minute(0).toISOString(),
        administeredDateTime: today.hour(12).minute(10).toISOString(),
        administeredBy: { display: 'Nurse Joy' },
      },
      {
        // Second administration intentionally overlapping SAME HOUR to test the sub-hour split UI!
        uuid: 'slot-3-2b',
        status: 'MISSED',
        scheduledDate: today.hour(12).minute(45).toISOString(),
      },
      {
        uuid: 'slot-3-3',
        status: 'SCHEDULED',
        scheduledDate: today.hour(18).minute(0).toISOString(),
      },
    ],
  },
] as unknown as MedicationSchedule[];
