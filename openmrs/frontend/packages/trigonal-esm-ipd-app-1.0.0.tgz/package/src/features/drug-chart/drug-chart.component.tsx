import React, { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Button,
  DataTable,
  InlineLoading,
  OverflowMenu,
  OverflowMenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
  Tooltip,
} from '@carbon/react';
import { Add, ChevronLeft, ChevronRight } from '@carbon/react/icons';
import { launchWorkspace } from '@openmrs/esm-framework';
import dayjs from 'dayjs';
import { useRtl } from '../../utils/use-rtl';
import type { MedicationSchedule, MedicationSlot } from '../../types';
import styles from './drug-chart.scss';

/** Colour coding for slot administration status */
const STATUS_TAG_TYPE: Record<MedicationSlot['status'], 'green' | 'blue' | 'red' | 'gray'> = {
  ADMINISTERED: 'green',
  SCHEDULED: 'blue',
  MISSED: 'red',
  NOT_ADMINISTERED: 'gray',
};

/** Hour labels for the 24-hour x-axis (00:00 – 23:00) */
const HOURS = Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, '0')}:00`);

interface SlotCellProps {
  slot: MedicationSlot | undefined;
  hour: string;
  scheduleUuid: string;
  patientUuid: string;
  visitUuid: string;
}

const SlotCell: React.FC<SlotCellProps> = ({ slot, hour, scheduleUuid, patientUuid, visitUuid }) => {
  const { t } = useTranslation();

  if (!slot) {
    return <TableCell key={hour} className={styles.slotCell} />;
  }

  const tagType = STATUS_TAG_TYPE[slot.status];
  const labelKey = `slotStatus${slot.status.charAt(0) + slot.status.slice(1).toLowerCase().replace(/_([a-z])/g, (_, c: string) => c.toUpperCase())}`;

  return (
    <TableCell className={styles.slotCell}>
      <Tooltip
        label={
          slot.administeredDateTime
            ? `${t(labelKey, slot.status)} — ${dayjs(slot.administeredDateTime).format('HH:mm')} by ${slot.administeredBy?.display ?? '—'}`
            : t(labelKey, slot.status)
        }
        align="bottom"
      >
        <Tag
          type={tagType}
          size="sm"
          className={styles.slotTag}
          onClick={
            slot.status === 'SCHEDULED'
              ? () =>
                  launchWorkspace('administer-ipd-medication', {
                    patientUuid,
                    visitUuid,
                    scheduleUuid,
                    slotUuid: slot.uuid,
                  })
              : undefined
          }
        >
          {slot.status === 'SCHEDULED' ? '+' : slot.status.charAt(0)}
        </Tag>
      </Tooltip>
    </TableCell>
  );
};

interface DrugChartProps {
  schedules: MedicationSchedule[];
  patientUuid: string;
  visitUuid: string;
  isLoading?: boolean;
  onAddMedication: () => void;
}

/**
 * DrugChartSection — IPD-01
 *
 * Renders a scrollable 24-hour timeline grid.
 *
 * Layout:
 *   Column 1 (sticky): Drug name + dose/route/frequency
 *   Columns 2-25:      Each hour of the currently viewed day
 *
 * The user can page between days with the chevron buttons.
 * Slot cells are clickable when SCHEDULED — they open the
 * "administer-ipd-medication" workspace.
 *
 * Migration note: replaces the legacy `Calendar.jsx` + `CalendarRow.jsx` +
 * `CalendarHeader.jsx` which used a custom Swiper-based horizontal scroll
 * and manually managed window resize listeners.
 */
const DrugChart: React.FC<DrugChartProps> = ({
  schedules,
  patientUuid,
  visitUuid,
  isLoading,
  onAddMedication,
}) => {
  const { t } = useTranslation();
  const isRtl = useRtl();
  const [viewDate, setViewDate] = useState<dayjs.Dayjs>(dayjs().startOf('day'));

  const prevDay = () => setViewDate((d) => d.subtract(1, 'day'));
  const nextDay = () => setViewDate((d) => d.add(1, 'day'));

  /*
   * In RTL layouts the visual "left" is the document's inline-end side,
   * so the chevron icons are swapped to match reading direction.
   * ChevronLeft visually points toward the past in LTR but toward the
   * future in RTL — so we reverse them when dir="rtl".
   */
  const PrevIcon = isRtl ? ChevronRight : ChevronLeft;
  const NextIcon = isRtl ? ChevronLeft : ChevronRight;

  /**
   * For each schedule, build a lookup map: hourString → MedicationSlot
   * so the grid render is O(1) per cell.
   */
  const slotsByScheduleAndHour = useMemo(() => {
    return schedules.map((schedule) => {
      const hourMap = new Map<string, MedicationSlot>();
      schedule.slots?.forEach((slot) => {
        const slotDay = dayjs(slot.scheduledDate).startOf('day');
        if (slotDay.isSame(viewDate, 'day')) {
          const hourKey = dayjs(slot.scheduledDate).format('HH:00');
          hourMap.set(hourKey, slot);
        }
      });
      return { schedule, hourMap };
    });
  }, [schedules, viewDate]);

  const drugHeaders = [
    { key: 'drug', header: t('drug', 'Drug') },
    ...HOURS.map((h) => ({ key: h, header: h })),
  ];

  const rows = slotsByScheduleAndHour.map(({ schedule, hourMap }) => ({
    id: schedule.uuid,
    drug: (
      <div className={styles.drugCell}>
        <span className={styles.drugName}>{schedule.drug.name}</span>
        <span className={styles.drugMeta}>
          {schedule.dose} {schedule.doseUnits?.display} · {schedule.route?.display} ·{' '}
          {schedule.frequency?.display}
        </span>
      </div>
    ),
    ...Object.fromEntries(HOURS.map((h) => [h, { slot: hourMap.get(h), hour: h }])),
  }));

  if (isLoading) {
    return <InlineLoading description={t('loadingDrugChart', 'Loading drug chart…')} />;
  }

  if (schedules.length === 0) {
    return (
      <div className={styles.emptyState}>
        <p>{t('noMedications', 'No medications scheduled')}</p>
        <Button kind="ghost" size="sm" renderIcon={Add} onClick={onAddMedication}>
          {t('addMedication', 'Add Medication')}
        </Button>
      </div>
    );
  }

  return (
    <div className={styles.drugChart}>
      {/* ── Date navigator ─────────────────────────────────────────── */}
      <div className={styles.dateNav}>
        <Button
          kind="ghost"
          size="sm"
          renderIcon={PrevIcon}
          iconDescription={t('previousDay', 'Previous day')}
          hasIconOnly
          onClick={prevDay}
        />
        <span className={styles.dateLabel}>{viewDate.format('DD MMM YYYY')}</span>
        <Button
          kind="ghost"
          size="sm"
          renderIcon={NextIcon}
          iconDescription={t('nextDay', 'Next day')}
          hasIconOnly
          onClick={nextDay}
          disabled={viewDate.isAfter(dayjs(), 'day')}
        />
        <div className={styles.dateNavSpacer} />
        <Button kind="ghost" size="sm" renderIcon={Add} onClick={onAddMedication}>
          {t('addMedication', 'Add Medication')}
        </Button>
      </div>

      {/* ── Legend ────────────────────────────────────────────────── */}
      <div className={styles.legend}>
        {(Object.entries(STATUS_TAG_TYPE) as Array<[MedicationSlot['status'], string]>).map(
          ([status, tagType]) => (
            <Tag key={status} type={tagType as 'green' | 'blue' | 'red' | 'gray'} size="sm">
              {t(`slotStatus${status.charAt(0) + status.slice(1).toLowerCase()}`, status)}
            </Tag>
          ),
        )}
      </div>

      {/* ── Timeline grid ─────────────────────────────────────────── */}
      <div className={styles.tableWrapper}>
        <DataTable rows={rows} headers={drugHeaders}>
          {({ rows: tableRows, headers, getTableProps, getHeaderProps, getRowProps }) => (
            <TableContainer>
              <Table {...getTableProps()} className={styles.timelineTable}>
                <TableHead>
                  <TableRow>
                    {headers.map((header) => {
                      const { onClick, ...rest } = getHeaderProps({ header });
                      return (
                        <TableHeader
                          key={header.key}
                          {...rest}
                          className={header.key === 'drug' ? styles.stickyCol : styles.hourHeader}
                          onClick={onClick as unknown as React.MouseEventHandler<HTMLButtonElement>}
                        >
                          {header.header}
                        </TableHeader>
                      );
                    })}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {tableRows.map((row) => (
                    <TableRow {...getRowProps({ row })} key={row.id}>
                      {row.cells.map((cell) => {
                        if (cell.info.header === 'drug') {
                          return (
                            <TableCell key={cell.id} className={styles.stickyCol}>
                              {cell.value}
                            </TableCell>
                          );
                        }
                        const { slot, hour } = cell.value as { slot: MedicationSlot | undefined; hour: string };
                        return (
                          <SlotCell
                            key={cell.id}
                            slot={slot}
                            hour={hour}
                            scheduleUuid={row.id}
                            patientUuid={patientUuid}
                            visitUuid={visitUuid}
                          />
                        );
                      })}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DataTable>
      </div>
    </div>
  );
};

export default DrugChart;
