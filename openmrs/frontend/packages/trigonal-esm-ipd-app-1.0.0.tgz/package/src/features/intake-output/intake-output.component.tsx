import React, { useState, useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import { Button, DataTableSkeleton, Table, TableHead, TableRow, TableHeader, TableBody, TableCell, Toggle } from '@carbon/react';
import { Add, ChevronLeft, ChevronRight } from '@carbon/react/icons';
import { launchWorkspace2, useConfig, useSession } from '@openmrs/esm-framework';
import type { IpdConfig } from '../../config-schema';
import { formatBsDate, isBsEnabled } from '../nursing-tasks/bs-calendar';
import { useIntakeOutput } from './use-intake-output';
import dayjs from 'dayjs';
import styles from './intake-output.scss';

interface IntakeOutputProps {
  patientUuid: string;
  visitUuid: string;
}

const IntakeOutput: React.FC<IntakeOutputProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const config = useConfig<IpdConfig>();
  const useBsCalendar: boolean = config?.useBsCalendar ?? false;

  // Only offer the toggle when the config flag is on AND the framework is
  // actually emitting BS dates (i.e. the locale includes the BS suffix).
  const bsAvailable = useBsCalendar && isBsEnabled();

  const [selectedDate, setSelectedDate] = useState(() => dayjs().startOf('day'));
  // AD/BS display toggle — only shown when bsAvailable
  const [showBs, setShowBs] = useState(bsAvailable);

  const { records, isLoading, error, mutate } = useIntakeOutput(patientUuid);

  const session = useSession();
  const privileges = session?.user?.privileges ?? [];
  const hasIpdAccess = privileges.some((p: any) => p.display === 'IPD Summary');
  const canAddObservations = privileges.some((p: any) => p.display === 'Add Observations');

  const handleAddIO = () => {
    launchWorkspace2('add-intake-output-form', {
      patientUuid,
      visitUuid,
      onSuccess: () => mutate(),
    });
  };

  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const d = dayjs(r.dateTime);
      return d.isSame(selectedDate, 'day');
    });
  }, [records, selectedDate]);

  const handlePrevDay = () => setSelectedDate((prev) => prev.subtract(1, 'day'));
  const handleNextDay = () => setSelectedDate((prev) => prev.add(1, 'day'));
  const handleGoToToday = () => setSelectedDate(dayjs().startOf('day'));

  const headers = [
    { key: 'time', header: t('time', 'Time') },
    { key: 'fluidIntakeType', header: t('fluidIntakeType', 'Fluid Intake Type') },
    { key: 'intakeVolume', header: t('intakeVolume', 'Intake Volume (ml)') },
    { key: 'rylesFeeding', header: t('rylesFeeding', 'Ryles Feeding (ml)') },
    { key: 'rylesAspirated', header: t('rylesAspirated', 'Ryles Aspirated (ml)') },
    { key: 'urineOutput', header: t('urineOutput', 'Urine Output (ml)') },
    { key: 'drainOutput', header: t('drainOutput', 'Drain Output (ml)') },
    { key: 'totalInput', header: t('totalInput', 'Total Input (ml)') },
    { key: 'totalOutput', header: t('totalOutput', 'Total Output (ml)') },
  ];

  const dailyTotals = useMemo(() => {
    return filteredRecords.reduce(
      (acc, curr) => {
        acc.input += curr.totalInput;
        acc.output += curr.totalOutput;
        return acc;
      },
      { input: 0, output: 0 }
    );
  }, [filteredRecords]);

  if (error) {
    return <div className={styles.error}>{t('errorLoadingIO', 'Error loading Intake/Output data')}</div>;
  }

  return (
    <div className={styles.intakeOutputContainer}>
      <div className={styles.header}>
        <div className={styles.navigation}>
          <Button kind="tertiary" size="sm" onClick={handleGoToToday}>
            {t('today', 'Today')}
          </Button>
          <div className={styles.navButtons}>
            <Button
              kind="tertiary"
              hasIconOnly
              renderIcon={ChevronLeft}
              size="sm"
              iconDescription={t('previousDay', 'Previous Day')}
              onClick={handlePrevDay}
            />
            <Button
              kind="tertiary"
              hasIconOnly
              renderIcon={ChevronRight}
              size="sm"
              iconDescription={t('nextDay', 'Next Day')}
              onClick={handleNextDay}
            />
          </div>
          <span className={styles.dateRange}>
            {bsAvailable && showBs
              ? formatBsDate(selectedDate.toDate(), true)
              : selectedDate.format('MMM D, YYYY')}
          </span>
          {/* AD / BS calendar toggle — only shown when BS dates are available */}
          {bsAvailable && (
            <Toggle
              id="intake-output-bs-toggle"
              size="sm"
              labelA="AD"
              labelB="BS"
              toggled={showBs}
              onToggle={(checked: boolean) => setShowBs(checked)}
              hideLabel
            />
          )}
        </div>
        {hasIpdAccess && canAddObservations && (
          <Button kind="ghost" size="sm" renderIcon={Add} onClick={handleAddIO}>
            {t('addIntakeOutput', 'Add Intake/Output')}
          </Button>
        )}
      </div>

      {isLoading ? (
        <DataTableSkeleton rowCount={5} columnCount={headers.length} />
      ) : (
        <div className={styles.tableWrapper}>
          <Table size="sm">
            <TableHead>
              <TableRow>
                {headers.map((h) => (
                  <TableHeader key={h.key} className={styles.wrappedHeader}>{h.header}</TableHeader>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredRecords.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={headers.length} className={styles.emptyCell}>
                    {t('noIORecordsForDay', 'No records found for this day')}
                  </TableCell>
                </TableRow>
              ) : (
                <>
                  {filteredRecords.map((row) => (
                    <TableRow key={row.uuid}>
                      <TableCell>{row.time}</TableCell>
                      <TableCell>{row.fluidIntakeType}</TableCell>
                      <TableCell>{row.intakeVolume}</TableCell>
                      <TableCell>{row.rylesFeeding}</TableCell>
                      <TableCell>{row.rylesAspirated}</TableCell>
                      <TableCell>{row.urineOutput}</TableCell>
                      <TableCell>{row.drainOutput}</TableCell>
                      <TableCell className={styles.totalCell}>{row.totalInput}</TableCell>
                      <TableCell className={styles.totalCell}>{row.totalOutput}</TableCell>
                    </TableRow>
                  ))}
                  <TableRow className={styles.footerRow}>
                    <TableCell colSpan={7} className={styles.footerLabel}>
                      {t('dailyTotals', 'Daily Totals')}
                    </TableCell>
                    <TableCell className={styles.footerTotal}>{dailyTotals.input} ml</TableCell>
                    <TableCell className={styles.footerTotal}>{dailyTotals.output} ml</TableCell>
                  </TableRow>
                  <TableRow className={styles.balanceRow}>
                    <TableCell colSpan={7} className={styles.footerLabel}>
                      {t('netBalance', 'Net Balance')}
                    </TableCell>
                    <TableCell colSpan={2} className={styles.balanceTotal}>
                      {dailyTotals.input - dailyTotals.output} ml
                    </TableCell>
                  </TableRow>
                </>
              )}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default IntakeOutput;
