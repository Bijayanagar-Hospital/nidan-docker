import React, { useMemo, useEffect } from 'react';
import {
  DataTable,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  TableContainer,
  TableExpandHeader,
  TableExpandRow,
  TableExpandedRow,
  DataTableSkeleton,
  Tag,
  Button,
  Modal,
  TextArea,
} from '@carbon/react';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import { launchWorkspace2, showSnackbar, useSession, formatDate, formatDatetime } from '@openmrs/esm-framework';
import { careSettingUuid } from '@openmrs/esm-patient-common-lib';
import { usePatientTreatments } from './use-patient-treatments';
import { stopDrugOrder, getEncounterType, getOrder } from './treatments.resource';
import { resolveDisplayName } from '../../utils/display';
import styles from './treatments.scss';

interface TreatmentsProps {
  patientUuid: string;
  visitUuid: string;
}

const Treatments: React.FC<TreatmentsProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const session = useSession();
  const hasIpdAccess = session?.user?.privileges?.some((p: any) => p.name === 'IPD Summary');
  const { treatmentsResponse, isLoading, isError, mutate } = usePatientTreatments(visitUuid);

  // Stop Drug Modal State
  const [showStopModal, setShowStopModal] = React.useState(false);
  const [stopOrder, setStopOrder] = React.useState<any>(null);
  const [stopReason, setStopReason] = React.useState('');
  const [isStopping, setIsStopping] = React.useState(false);

  useEffect(() => {
    const handleRefresh = () => mutate();
    window.addEventListener('ipd:medication-refresh', handleRefresh);
    return () => window.removeEventListener('ipd:medication-refresh', handleRefresh);
  }, [mutate]);

  const handleStopSubmit = async () => {
    setIsStopping(true);
    try {
      const encounterType = await getEncounterType('Consultation');
      const locationUuid = session?.sessionLocation?.uuid ?? null;

      if (!stopOrder?.orderUuid || !patientUuid || !visitUuid || !encounterType?.uuid) {
        throw new Error('Missing required stop-order context');
      }

      const orderData = await getOrder(stopOrder.orderUuid);

      const ordererUuid = session?.currentProvider?.uuid || stopOrder?.providerUuid || null;
      const encounterUuid = stopOrder?.encounterUuid ?? null;
      const drugUuid = orderData?.drug?.uuid ?? stopOrder?.drugUuid ?? stopOrder?.drug?.uuid ?? null;
      const conceptUuid = orderData?.concept?.uuid ?? stopOrder?.conceptUuid ?? stopOrder?.drug?.concept?.uuid ?? stopOrder?.concept?.uuid ?? null;

      const payload = {
        patient: patientUuid,
        location: locationUuid,
        encounterType: encounterType.uuid,
        visit: visitUuid,
        obs: [],
        orders: [
          {
            action: 'DISCONTINUE',
            type: 'drugorder',
            previousOrder: stopOrder.orderUuid,
            patient: patientUuid,
            careSetting: careSettingUuid,
            encounter: encounterUuid,
            orderer: ordererUuid,
            concept: conceptUuid,
            drug: drugUuid,
            orderReasonNonCoded: stopReason || null,
            dateStopped: dayjs().toISOString(),
          },
        ],
      };
      await stopDrugOrder(payload);
      showSnackbar({ title: t('drugStopped', 'Medication stopped successfully'), kind: 'success' });
      mutate();
      window.dispatchEvent(new CustomEvent('ipd:medication-refresh'));
      setShowStopModal(false);
    } catch (err) {
      showSnackbar({ title: t('stopError', 'Failed to stop medication'), kind: 'error' });
      console.log('error', err);
    } finally {
      setIsStopping(false);
    }
  };

  const headers = [
    { key: 'startDate', header: t('startDate', 'Start Date') },
    { key: 'drugName', header: t('drugName', 'Drug Name') },
    { key: 'dosageDetails', header: t('dosageDetails', 'Dosage Details') },
    { key: 'status', header: t('status', 'Status') },
    { key: 'providerName', header: t('providerName', 'Provider Name') },
    { key: 'actions', header: t('actions', 'Actions') },
  ];

  const rows = useMemo(() => {
    if (!treatmentsResponse) return [];

    const mappedRows: any[] = [];

    // Map IPD Drug Orders
    if (treatmentsResponse.ipdDrugOrders?.length > 0) {
      treatmentsResponse.ipdDrugOrders.forEach((order) => {
        const { providerName, instructions, additionalInstructions, administrationInstructions, drugOrderSchedule, drugName } = order;

        // Dosing Logic
        const doseStr = order.dose ? `${order.dose} ${resolveDisplayName(order.doseUnitsName) || ''}` : '';
        const routeStr = order.routeName ? `- ${resolveDisplayName(order.routeName)}` : '';
        const freqStr = order.frequency ? `- ${resolveDisplayName(order.frequency)}` : '';
        const durationStr = order.duration ? `- for ${order.duration} ${resolveDisplayName(order.durationUnitsName) || ''}` : '';

        let dosingInstructionsStr = `${doseStr} ${routeStr} ${freqStr} ${durationStr}`.trim();

        // Status Logic
        let statusEl = null;
        if (order.dateStopped) {
          statusEl = <span className={styles.redText}>{t('stopped', 'Stopped')}</span>;
        } else if (drugOrderSchedule?.allSlotsAttended) {
          statusEl = <span>{t('completed', 'Completed')}</span>;
        }

        // Action Logic flags
        const isStopped = !!order.dateStopped;
        const asNeeded = !!order.asNeeded;
        const adminStarted = !!drugOrderSchedule?.medicationAdministrationStarted;
        const pendingSlots = !!drugOrderSchedule?.pendingSlotsAvailable;

        const handleAction = (isEdit = false) => {
          launchWorkspace2('add-ipd-medication', {
            drugOrder: order,
            isEdit,
            mutate,
          });
        };

        const showStopButton = !isStopped && adminStarted && pendingSlots;
        const showEditButton = !isStopped && !!drugOrderSchedule && !adminStarted;
        const showAddButton = !isStopped && !drugOrderSchedule;

        mappedRows.push({
          id: order.orderUuid,
          startDate: order.effectiveStartDate ? formatDate(new Date(order.effectiveStartDate), { mode: 'wide', time: false }) : '',
          _sortDate: order.effectiveStartDate ? new Date(order.effectiveStartDate).getTime() : 0,
          drugName: (
            <span className={isStopped ? styles.strikeThrough : ''}>
              <div>
                {asNeeded? <span className={styles.treatmentsDrugName}> {drugName} <Tag type="blue" size="sm">{t('rxPrn', 'Rx-PRN')}</Tag></span> : <span className={styles.treatmentsDrugName}>{drugName} <Tag type="blue" size="sm">{t('rx', 'Rx')}</Tag></span>}
              </div>
            </span>
          ),
          dosageDetails: (
            <span className={isStopped ? styles.strikeThrough : ''}>
              {dosingInstructionsStr}
            </span>
          ),
          status: statusEl,
          providerName: resolveDisplayName(providerName),
          actions: !isStopped && (
            <div className={styles.actionContainer}>
              {hasIpdAccess && showAddButton && (
                <a className={styles.actionLink} onClick={(e) => { e.preventDefault(); handleAction(); }}>
                  {asNeeded ? t('addToTasks', 'Add PRN Tasks') : t('addToDrugChart', 'Add to Drug Chart')}
                </a>
              )}
              {hasIpdAccess && showEditButton && (
                <a className={styles.actionLink} onClick={(e) => { e.preventDefault(); handleAction(true); }}>
                  {t('editDrugChart', 'Edit Drug Chart')}
                </a>
              )}
              {hasIpdAccess && showStopButton && (
                <a className={styles.actionLink} onClick={(e) => { e.preventDefault(); setStopOrder(order); setShowStopModal(true); }}>
                  {t('stopDrug', 'Stop drug')}
                </a>
              )}
            </div>
          ),
          // Store raw properties for Expand payload
          expandedData: {
            instructions: resolveDisplayName(instructions),
            additionalInstructions: resolveDisplayName(additionalInstructions),
            administrationInstructions: resolveDisplayName(administrationInstructions),
            recordedDateTime: order.dateActivated ? formatDatetime(new Date(order.dateActivated), { mode: 'wide' }) : '',
            stopReason: isStopped && order.orderReasonText || resolveDisplayName(order.orderReasonConcept?.name),
            indication: !isStopped && order.orderReasonText || resolveDisplayName(order.orderReasonConcept?.name),
            prnReason: order.asNeededCondition && order.asNeededCondition,
            creatorAdditionalData: !isStopped ? `${resolveDisplayName(providerName)} | ${order.dateActivated ? formatDatetime(new Date(order.dateActivated), { mode: 'wide' }) : ''}` : null,
            stopperAdditionalData: isStopped ? `${resolveDisplayName(providerName)} | ${order.dateStopped ? formatDatetime(new Date(order.dateStopped), { mode: 'wide' }) : ''}` : null,
          }
        });
      });
    }

    const emergencyMeds = treatmentsResponse?.emergencyMedications ?? [];

    // Map Emergency Medications
    if (emergencyMeds.length > 0) {
      emergencyMeds.forEach((item) => {
        const med = item.medicationAdministration || item;
        const drugName = med.drug?.display;
        const providers = med.providers || [];
        const notes = med.notes || [];

        const verifier = providers.find((p) => p.function === 'Verifier');
        const performer = providers.find((p) => p.function === 'Performer' || p.function === 'Requester');
        const displayProvider = verifier || performer;

        const statusEl = verifier ? (
          <span>{t('acknowledged', 'Acknowledged')}</span>
        ) : (
          <span className={styles.redText}>{t('notAcknowledged', 'Not Acknowledged')}</span>
        );

        // Process notes
        const administrationNotes = [];
        const acknowledgmentNotes = [];

        notes.forEach((n) => {
          const authorRoles = providers.filter((p) => p.provider?.uuid === n.author?.uuid).map((p) => p.function);
          const noteStr = `${n.author?.display} (${formatDatetime(new Date(n.recordedTime), { mode: 'wide' })}): ${n.text}`;

          if (authorRoles.includes('Verifier')) {
            acknowledgmentNotes.push(noteStr);
          } else {
            administrationNotes.push(noteStr);
          }
        });

        mappedRows.push({
          id: item.uuid,
          startDate: med.administeredDateTime ? formatDatetime(new Date(med.administeredDateTime), { mode: 'wide' }) : '',
          _sortDate: med.administeredDateTime ? new Date(med.administeredDateTime).getTime() : 0,
          drugName: (
            <div>
              <span className={styles.treatmentsDrugName}>
                {drugName} <Tag type="red" size="sm">{t('emergency', 'Emerg')}</Tag>
              </span>
            </div>
          ),
          dosageDetails: `${med.dose} ${med.doseUnits?.display || ''} - ${med.route?.display || ''}`,
          status: statusEl,
          providerName: displayProvider?.provider?.display,
          actions: null,
          expandedData: {
            administrationNotes,
            acknowledgmentNotes,
          },
        });
      });
    }

    // Sort by chronological start
    return mappedRows.sort((a, b) => a._sortDate - b._sortDate);
  }, [treatmentsResponse, t]);

  // Rename original raw memoized object so `<DataTable>` doesn't conflict
  const mappedRows = rows;

  if (isLoading) {
    return <DataTableSkeleton columnCount={6} rowCount={4} />;
  }

  if (isError) {
    return <div className={styles.emptyState}>{t('errorFetchingTreatments', 'Error fetching treatments data')}</div>;
  }

  if (rows.length === 0) {
    return (
      <div className={styles.emptyState}>
        <p>{t('noTreatmentsMessage', 'No IPD Medication is prescribed for this patient yet')}</p>
      </div>
    );
  }

  return (
    <div className={styles.treatmentsContainer}>
      <DataTable rows={mappedRows} headers={headers} useZebraStyles>
        {({ rows, headers, getHeaderProps, getRowProps }) => (
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {/* @ts-ignore - Carbon strictly binds these to a HOC mapping */}
                  <TableExpandHeader aria-label="expand row" expandIconDescription="Expand/Collapse row" />
                  {headers.map((header) => (
                    <TableHeader {...(getHeaderProps({ header }) as any)} key={header.key}>
                      {header.header}
                    </TableHeader>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {rows.map((row) => {
                  const originalRow = mappedRows.find(r => r.id === row.id);
                  const expandedData = originalRow?.expandedData;

                  return (
                    <React.Fragment key={row.id}>
                      <TableExpandRow aria-controls={`expanded-row-${row.id}`} {...(getRowProps({ row }) as any)}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableExpandRow>

                      {/* Expaned Row containing additional legacy details */}
                      <TableExpandedRow
                        colSpan={headers.length + 1}
                        className={styles.expandedDetails}
                      >
                        <div className={styles.expandedBlock}>
                          {expandedData?.instructions && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('instructions', 'Instructions')}:</span>
                              <span>{expandedData.instructions}</span>
                            </div>
                          )}
                          {expandedData?.additionalInstructions && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('additionalInstructions', 'Additional Dosing Instructions')}:</span>
                              <span>{expandedData.additionalInstructions}</span>
                            </div>
                          )}
                          {expandedData?.administrationInstructions && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('administrationInstructions', 'Administration Instructions')}:</span>
                              <span>{expandedData.administrationInstructions}</span>
                            </div>
                          )}
                          {expandedData?.prnReason && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('prnReason', 'PRN Reason')}:</span>
                              <span>{expandedData.prnReason}</span>
                            </div>
                          )}
                          {expandedData?.stopReason && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('stopReason', 'Stop Reason')}:</span>
                              <span>{expandedData.stopReason}</span>
                            </div>
                          )}
                          {expandedData?.indication && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('indication', 'Indication')}:</span>
                              <span>{expandedData.indication}</span>
                            </div>
                          )}
                          {expandedData?.creatorAdditionalData && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('createdBy', 'Created by')}:</span>
                              <span>{expandedData.creatorAdditionalData}</span>
                            </div>
                          )}
                          {expandedData?.stopperAdditionalData && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('stopperProvider', 'Stopped by')}:</span>
                              <span>{expandedData.stopperAdditionalData}</span>
                            </div>
                          )}
                          {expandedData?.administrationNotes?.length > 0 && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('administrationNotes', 'Administration Notes')}:</span>
                              <div>
                                {expandedData.administrationNotes.map((note, i) => (
                                  <div key={i}>{note}</div>
                                ))}
                              </div>
                            </div>
                          )}
                          {expandedData?.acknowledgmentNotes?.length > 0 && (
                            <div className={styles.detailRow}>
                              <span className={styles.detailLabel}>{t('acknowledgmentNotes', 'Acknowledgment Notes')}:</span>
                              <div>
                                {expandedData.acknowledgmentNotes.map((note, i) => (
                                  <div key={i}>{note}</div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </TableExpandedRow>
                    </React.Fragment>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </DataTable>

      {/* Stop Drug Modal */}
      <Modal
        open={showStopModal}
        modalHeading={t('stopMedication', 'Stop Medication')}
        primaryButtonText={t('stopDrug', 'Stop drug')}
        secondaryButtonText={t('cancel', 'Cancel')}
        onRequestClose={() => setShowStopModal(false)}
        onRequestSubmit={handleStopSubmit}
        primaryButtonDisabled={!stopReason || isStopping}
      >
        <p style={{ marginBottom: '1rem' }}>
          {t('stopConfirmation', 'Are you sure you want to stop this drug? You will not be able to reverse this decision.')}
        </p>
        <TextArea
          id="stop-reason"
          labelText={<>
            {t('stopReason', 'Please mention a reason')}<span className={styles.requiredIndicator}>*</span>
          </>}
          placeholder={t('reasonPlaceholder', 'Enter reason...')}
          value={stopReason}
          onChange={(e) => setStopReason(e.target.value)}
          rows={2}
        />
      </Modal>
    </div>
  );
};

export default Treatments;
