import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import {
  DataTable,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  DataTableSkeleton,
  InlineNotification,
} from '@carbon/react';
import { formatDate, parseDate } from '@openmrs/esm-framework';
import { useIpdVitals } from './use-vitals';
import { resolveDisplayName } from '../../utils/display';
import styles from './vitals.scss';

interface VitalsProps {
  patientUuid: string;
  visitUuid?: string;
}

const Vitals: React.FC<VitalsProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();
  const { vitals, biometrics, isLoading, error } = useIpdVitals(patientUuid);

  const vitalsHeaders = [
    { key: 'date', header: t('date', 'Date') },
    { key: 'temperature', header: t('temperature', 'Temp') },
    { key: 'bloodPressure', header: t('bloodPressure', 'BP') },
    { key: 'pulse', header: t('pulse', 'Pulse') },
    { key: 'respiratoryRate', header: t('respiratoryRate', 'R. Rate') },
    { key: 'spo2', header: t('spo2', 'SpO2') },
  ];

  const biometricsHeaders = [
    { key: 'date', header: t('date', 'Date') },
    { key: 'height', header: t('height', 'Height (cm)') },
    { key: 'weight', header: t('weight', 'Weight (kg)') },
    { key: 'bmi', header: t('bmi', 'BMI') },
    { key: 'muac', header: t('muac', 'MUAC (cm)') },
  ];

  const vitalsRows = useMemo(() => {
    return vitals.map((v, index) => ({
      id: v.date || `v-${index}`,
      date: v.date
        ? formatDate(parseDate(v.date.toString()), { mode: 'wide', time: true })
        : '--',
      temperature: v.temperature ? `${resolveDisplayName(v.temperature)} °C` : '--',
      bloodPressure: v.systolic && v.diastolic ? `${resolveDisplayName(v.systolic)}/${resolveDisplayName(v.diastolic)}` : '--',
      pulse: v.pulse ? `${resolveDisplayName(v.pulse)} bpm` : '--',
      respiratoryRate: v.respiratoryRate ? `${resolveDisplayName(v.respiratoryRate)} /min` : '--',
      spo2: v.spo2 ? `${resolveDisplayName(v.spo2)} %` : '--',
    }));
  }, [vitals]);

  const biometricsRows = useMemo(() => {
    return biometrics.map((b, index) => ({
      id: b.date || `b-${index}`,
      date: b.date
        ? formatDate(parseDate(b.date.toString()), { mode: 'wide', time: true })
        : '--',
      height: b.height ? `${resolveDisplayName(b.height)}` : '--',
      weight: b.weight ? `${resolveDisplayName(b.weight)}` : '--',
      bmi: b.bmi ? `${resolveDisplayName(b.bmi)}` : '--',
      muac: b.muac ? `${resolveDisplayName(b.muac)}` : '--',
    }));
  }, [biometrics]);

  if (isLoading) {
    return <DataTableSkeleton columnCount={6} rowCount={3} zebra />;
  }

  if (error) {
    return (
      <InlineNotification
        kind="error"
        title={t('errorFetchingVitals', 'Error fetching vitals')}
        subtitle={error.message || 'An unknown error occurred'}
      />
    );
  }

  return (
    <div className={styles.vitalsContainer}>
      <div className={styles.tableSection}>
        <h4 className={styles.sectionTitle}>{t('vitalSigns', 'Vital Signs')}</h4>
        {vitalsRows.length > 0 ? (
          <DataTable rows={vitalsRows} headers={vitalsHeaders}>
            {({ rows, headers, getTableProps, getHeaderProps, getRowProps }) => (
              <Table {...getTableProps()} size="sm">
                <TableHead>
                  <TableRow>
                    {headers.map((header) => (
                      <TableHeader key={header.key} {...(getHeaderProps({ header }) as any)}>
                        {header.header}
                      </TableHeader>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow {...getRowProps({ row })}>
                      {row.cells.map((cell) => (
                        <TableCell key={cell.id}>{cell.value}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </DataTable>
        ) : (
          <InlineNotification
            kind="info"
            title={t('noVitals', 'No vitals recorded')}
            subtitle={t('noVitalsHint', 'There are no vital signs recorded for this patient.')}
            hideCloseButton
          />
        )}
      </div>

      <div className={styles.tableSection}>
        <h4 className={styles.sectionTitle}>{t('nutritionalValues', 'Nutritional Values')}</h4>
        {biometricsRows.length > 0 ? (
          <DataTable rows={biometricsRows} headers={biometricsHeaders}>
            {({ rows, headers, getTableProps, getHeaderProps, getRowProps }) => (
              <Table {...getTableProps()} size="sm">
                <TableHead>
                  <TableRow>
                    {headers.map((header) => (
                      <TableHeader key={header.key} {...(getHeaderProps({ header }) as any)}>
                        {header.header}
                      </TableHeader>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow {...getRowProps({ row })}>
                      {row.cells.map((cell) => (
                        <TableCell key={cell.id}>{cell.value}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </DataTable>
        ) : (
          <InlineNotification
            kind="info"
            title={t('noNutritionalValues', 'No nutritional values recorded')}
            subtitle={t('noNutritionalValuesHint', 'There are no biometrics or nutritional values recorded for this patient.')}
            hideCloseButton
          />
        )}
      </div>
    </div>
  );
};

export default Vitals;
