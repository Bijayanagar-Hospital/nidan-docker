import React from 'react';
import { useTranslation } from 'react-i18next';
import { ExtensionSlot, useExtensionSlotMeta } from '@openmrs/esm-framework';
import { InlineNotification } from '@carbon/react';
import styles from './vitals.scss';

interface VitalsProps {
  patientUuid: string;
  visitUuid: string;
}

/**
 * VitalsSection — IPD-04
 *
 * Delegates entirely to the O3 extension slot system.
 *
 * - Slot name: `ipd-VT-slot`
 * - Any installed ESM (e.g. `@openmrs/esm-patient-vitals-app`) can contribute
 *   its vitals chart/table by registering an extension targeting this slot.
 * - If no extensions are registered, a helpful empty-state message is shown.
 *
 * ## How to wire @openmrs/esm-patient-vitals-app into this slot
 *
 * In `spa-assemble-config.json` or the O3 runtime config, add:
 * ```json
 * {
 *   "@openmrs/esm-patient-vitals-app": {
 *     "extensionSlots": {
 *       "ipd-VT-slot": {
 *         "add": ["vitals-overview-widget"]
 *       }
 *     }
 *   }
 * }
 * ```
 *
 * Migration note: the legacy app fetched vitals from the Bahmni-specific
 * `PATIENT_VITALS_URL` (bahmnicore/diseaseSummaryData) and rendered them
 * in a custom table. The O3 esm-patient-vitals-app uses the FHIR Observation
 * endpoint and already handles all display logic. We just need to open the slot.
 */
const Vitals: React.FC<VitalsProps> = ({ patientUuid, visitUuid }) => {
  const { t } = useTranslation();

  // useExtensionSlotMeta lets us detect whether anything has registered
  const slotMeta = useExtensionSlotMeta('ipd-VT-slot');
  const hasExtensions = Object.keys(slotMeta ?? {}).length > 0;

  return (
    <div className={styles.vitals}>
      {!hasExtensions && (
        <InlineNotification
          kind="info"
          title={t('noVitalsConfigured', 'No vitals extensions registered for IPD')}
          subtitle={t(
            'noVitalsConfiguredHint',
            'Register an extension into the "ipd-VT-slot" to display vitals here.',
          )}
          hideCloseButton
        />
      )}
      <ExtensionSlot
        name="ipd-VT-slot"
        state={{ patientUuid, visitUuid }}
      />
    </div>
  );
};

export default Vitals;
