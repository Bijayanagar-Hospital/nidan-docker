import React from 'react';
import { render, screen } from '@testing-library/react';
import Allergies from '../features/allergies/allergies.component';
import { usePatientAllergies } from '../features/patient-ipd/use-ipd-patient';
import type { FhirAllergyIntolerance } from '../features/patient-ipd/use-ipd-patient';

jest.mock('../features/patient-ipd/use-ipd-patient', () => ({
  ...jest.requireActual('../features/patient-ipd/use-ipd-patient'),
  usePatientAllergies: jest.fn(),
}));

const mockAllergy: FhirAllergyIntolerance = {
  id: 'allergy-1',
  resourceType: 'AllergyIntolerance',
  category: ['medication'],
  criticality: 'high',
  code: { coding: [{ code: 'PENICILLIN', display: 'Penicillin' }], text: 'Penicillin' },
  patient: { reference: 'Patient/p-uuid', display: 'Test Patient' },
  onsetDateTime: '2025-01-10T00:00:00',
  reaction: [
    {
      manifestation: [{ coding: [{ display: 'Hives' }] }],
      severity: 'moderate',
    },
  ],
};

describe('AllergiesSection', () => {
  afterEach(() => jest.clearAllMocks());

  it('shows skeleton while loading', () => {
    (usePatientAllergies as jest.Mock).mockReturnValue({
      allergies: [],
      isLoading: true,
      error: null,
    });

    const { container } = render(<Allergies patientUuid="p-uuid" />);
    expect(container.querySelector('.cds--skeleton')).toBeInTheDocument();
  });

  it('shows error notification on load failure', () => {
    (usePatientAllergies as jest.Mock).mockReturnValue({
      allergies: [],
      isLoading: false,
      error: new Error('FHIR error'),
    });

    render(<Allergies patientUuid="p-uuid" />);
    expect(screen.getByText('Failed to load allergies')).toBeInTheDocument();
  });

  it('shows empty state when no allergies', () => {
    (usePatientAllergies as jest.Mock).mockReturnValue({
      allergies: [],
      isLoading: false,
      error: null,
    });

    render(<Allergies patientUuid="p-uuid" />);
    expect(screen.getByText('No allergies recorded')).toBeInTheDocument();
  });

  it('renders allergen name in the table', () => {
    (usePatientAllergies as jest.Mock).mockReturnValue({
      allergies: [mockAllergy],
      isLoading: false,
      error: null,
    });

    render(<Allergies patientUuid="p-uuid" />);
    expect(screen.getByText('Penicillin')).toBeInTheDocument();
  });

  it('renders criticality tag', () => {
    (usePatientAllergies as jest.Mock).mockReturnValue({
      allergies: [mockAllergy],
      isLoading: false,
      error: null,
    });

    render(<Allergies patientUuid="p-uuid" />);
    expect(screen.getByText('high')).toBeInTheDocument();
  });

  it('renders reaction manifestation', () => {
    (usePatientAllergies as jest.Mock).mockReturnValue({
      allergies: [mockAllergy],
      isLoading: false,
      error: null,
    });

    render(<Allergies patientUuid="p-uuid" />);
    expect(screen.getByText('Hives')).toBeInTheDocument();
  });

  it('renders category column', () => {
    (usePatientAllergies as jest.Mock).mockReturnValue({
      allergies: [mockAllergy],
      isLoading: false,
      error: null,
    });

    render(<Allergies patientUuid="p-uuid" />);
    expect(screen.getByText('medication')).toBeInTheDocument();
  });
});
