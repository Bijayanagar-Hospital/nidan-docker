import React from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { launchWorkspace } from '@openmrs/esm-framework';
import dayjs from 'dayjs';
import DrugChart from '../features/drug-chart/drug-chart.component';
import type { MedicationSchedule } from '../types';

jest.mock('@openmrs/esm-framework', () => ({
  ...jest.requireActual('@openmrs/esm-framework/mock'),
  launchWorkspace: jest.fn(),
}));

const PATIENT_UUID = 'p-uuid';
const VISIT_UUID = 'v-uuid';
const today = dayjs().startOf('day');

const makeSchedule = (overrides: Partial<MedicationSchedule> = {}): MedicationSchedule => ({
  uuid: 'sched-1',
  drug: { uuid: 'd1', display: 'Paracetamol', name: 'Paracetamol' },
  dose: 500,
  doseUnits: { uuid: 'mg', display: 'mg' },
  frequency: { uuid: 'bd', display: 'Twice daily' },
  route: { uuid: 'oral', display: 'Oral' },
  startDate: today.toISOString(),
  slots: [
    {
      uuid: 'slot-1',
      scheduledDate: today.hour(8).toISOString(),
      status: 'ADMINISTERED',
      administeredDateTime: today.hour(8).minute(10).toISOString(),
      administeredBy: { uuid: 'prov-1', display: 'Nurse A' },
    },
    {
      uuid: 'slot-2',
      scheduledDate: today.hour(20).toISOString(),
      status: 'SCHEDULED',
    },
  ],
  ...overrides,
});

describe('DrugChart', () => {
  it('renders the drug name and metadata', () => {
    render(
      <DrugChart
        schedules={[makeSchedule()]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={jest.fn()}
      />,
    );

    expect(screen.getByText('Paracetamol')).toBeInTheDocument();
    expect(screen.getByText(/500.*mg.*Oral.*Twice daily/)).toBeInTheDocument();
  });

  it('renders all 24 hour column headers', () => {
    render(
      <DrugChart
        schedules={[makeSchedule()]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={jest.fn()}
      />,
    );

    expect(screen.getByText('08:00')).toBeInTheDocument();
    expect(screen.getByText('20:00')).toBeInTheDocument();
  });

  it('shows today\'s date in the navigator', () => {
    render(
      <DrugChart
        schedules={[makeSchedule()]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={jest.fn()}
      />,
    );

    expect(screen.getByText(today.format('DD MMM YYYY'))).toBeInTheDocument();
  });

  it('navigates to the previous day on chevron click', async () => {
    const user = userEvent.setup();
    render(
      <DrugChart
        schedules={[makeSchedule()]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={jest.fn()}
      />,
    );

    await user.click(screen.getByRole('button', { name: 'Previous day' }));
    expect(
      screen.getByText(today.subtract(1, 'day').format('DD MMM YYYY')),
    ).toBeInTheDocument();
  });

  it('disables "Next day" button when viewing today', () => {
    render(
      <DrugChart
        schedules={[makeSchedule()]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={jest.fn()}
      />,
    );

    expect(screen.getByRole('button', { name: 'Next day' })).toBeDisabled();
  });

  it('shows empty state and Add Medication button when no schedules', () => {
    const onAdd = jest.fn();
    render(
      <DrugChart
        schedules={[]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={onAdd}
      />,
    );

    expect(screen.getByText('No medications scheduled')).toBeInTheDocument();
    expect(screen.getByText('Add Medication')).toBeInTheDocument();
  });

  it('calls onAddMedication when clicking Add Medication in empty state', async () => {
    const onAdd = jest.fn();
    const user = userEvent.setup();
    render(
      <DrugChart
        schedules={[]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={onAdd}
      />,
    );

    await user.click(screen.getByText('Add Medication'));
    expect(onAdd).toHaveBeenCalledTimes(1);
  });

  it('renders SCHEDULED slot tag and opens workspace on click', async () => {
    const user = userEvent.setup();
    render(
      <DrugChart
        schedules={[makeSchedule()]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={jest.fn()}
      />,
    );

    // SCHEDULED slot → tag with "+" text
    const scheduledTag = screen.getAllByText('+')[0];
    await user.click(scheduledTag);

    expect(launchWorkspace).toHaveBeenCalledWith(
      'administer-ipd-medication',
      expect.objectContaining({
        patientUuid: PATIENT_UUID,
        visitUuid: VISIT_UUID,
        slotUuid: 'slot-2',
      }),
    );
  });

  it('shows legend tags for all status types', () => {
    render(
      <DrugChart
        schedules={[makeSchedule()]}
        patientUuid={PATIENT_UUID}
        visitUuid={VISIT_UUID}
        onAddMedication={jest.fn()}
      />,
    );

    // Legend always shows all 4 statuses
    expect(screen.getByText(/administered/i)).toBeInTheDocument();
    expect(screen.getByText(/scheduled/i)).toBeInTheDocument();
    expect(screen.getByText(/missed/i)).toBeInTheDocument();
  });
});
