export const moduleName = '@trigonal/esm-ipd-app';

/** Base SPA path that this module mounts at */
export const ipdBasePath = `${window.spaBase}/home/ipd`;

/** IPD REST API endpoints — relative to /openmrs/ws/rest/v1 */
export const restV1 = '/ws/rest/v1';
export const fhirR4 = '/ws/fhir2/R4';

export const IPD_WARDS_URL = `${restV1}/admissionLocation`;
export const WARD_SUMMARY_URL = `${restV1}/ipd/wards/{wardId}/summary`;
export const WARD_PATIENTS_URL = `${restV1}/ipd/wards/{wardId}/patients`;
export const MY_WARD_PATIENTS_URL = `${restV1}/ipd/wards/{wardId}/myPatients`;
export const WARD_PATIENT_SEARCH_URL = `${restV1}/ipd/wards/{wardId}/patients/search`;

export const MEDICATION_SCHEDULE_URL = `${restV1}/ipd/schedule/type/medication`;
export const MEDICATION_SCHEDULE_EDIT_URL = `${restV1}/ipd/schedule/type/medication/edit`;
export const MEDICATION_ADMINISTRATIONS_URL = `${restV1}/ipd/scheduledMedicationAdministrations`;
export const EMERGENCY_MEDICATIONS_URL = `${restV1}/ipd/adhocMedicationAdministrations`;
export const PATIENT_MEDICATION_SUMMARY_URL = `${restV1}/ipd/schedule/type/medication/patientsMedicationSummary`;

export const CARE_TEAM_URL = `${restV1}/ipd/careteam/participants`;
export const NURSING_TASKS_URL = `${restV1}/ipd/tasks`;
export const BED_INFORMATION_URL = `${restV1}/beds`;

export const ALLERGIES_URL = `${fhirR4}/AllergyIntolerance`;
export const CONDITIONS_URL = `${fhirR4}/Condition`;

/** Component keys — mirror legacy constants.js for config compatibility */
export const componentKeys = {
  ALLERGIES: 'AL',
  CONDITIONS: 'CO',
  VITALS: 'VT',
  DIAGNOSIS: 'DG',
  TREATMENTS: 'TR',
  NURSING_TASKS: 'NT',
  DRUG_CHART: 'DC',
  INTAKE_OUTPUT: 'IO',
  NON_MEDICATION_TASKS: 'NMT',
} as const;

export type ComponentKey = (typeof componentKeys)[keyof typeof componentKeys];

/** Privilege constants */
export const PRIVILEGES = {
  ADT: 'Assign Beds',
  EDIT_MEDICATION_TASKS: 'Edit Medication Tasks',
  ADD_TASKS: 'Add Tasks',
  EDIT_TASKS: 'Edit Tasks',
  EDIT_MEDICATION_ADMINISTRATION: 'Edit Medication Administration',
} as const;

export const WARD_SUMMARY_HEADER = {
  TOTAL_PATIENTS: 'TOTAL_PATIENTS',
  MY_PATIENTS: 'MY_PATIENTS',
} as const;

export type WardSummaryHeader = (typeof WARD_SUMMARY_HEADER)[keyof typeof WARD_SUMMARY_HEADER];

export const defaultDateFormat = 'DD MMM YYYY';
export const defaultDateTimeFormat = 'DD MMM YYYY hh:mm a';
