import React, { useMemo } from 'react';
import { useTranslation } from 'react-i18next';
import last from 'lodash-es/last';
import { BrowserRouter, useLocation } from 'react-router-dom';
import { ConfigurableLink } from '@openmrs/esm-framework';
import HospitalBed from '@carbon/icons-react/es/HospitalBed';
import styles from './patient-ipd-link.module.scss';

interface PatientIpdLinkConfig {
  title: string;
}

/**
 * Link that appears in the patient chart's left-panel navigation.
 * Navigates to /patient/{patientUuid}/chart/ipd-summary.
 *
 * The `to` prop must be an absolute SPA path so that `navigate()` in
 * @openmrs/esm-framework calls `single-spa.navigateToUrl()` instead of
 * falling back to `window.location.assign()` (which triggers a full-page
 * reload and resolves relative to the wrong base).
 *
 * The patient UUID is extracted from the current URL path using the same
 * regex O3's `getPatientUuidFromUrl()` utility uses internally
 * (/patient/{uuid}/...).
 */
export const createPatientIpdLink = (config: PatientIpdLinkConfig) => () => {
  return (
    <BrowserRouter>
      <PatientIpdLinkExtension config={config} />
    </BrowserRouter>
  );
};

function PatientIpdLinkExtension({ config }: { config: PatientIpdLinkConfig }) {
  const { t } = useTranslation();
  const { title } = config;
  const location = useLocation();

  const patientUuid = useMemo(() => {
    const match = /\/patient\/([a-zA-Z0-9\-]+)/.exec(location.pathname);
    return match?.[1] ?? '';
  }, [location.pathname]);

  const urlSegment = useMemo(
    () => decodeURIComponent(last(location.pathname.split('/')) ?? ''),
    [location.pathname],
  );

  const ipdPath = `${window.getOpenmrsSpaBase()}patient/${patientUuid}/chart/ipd-summary`;

  return (
    <ConfigurableLink
      to={ipdPath}
      className={`cds--side-nav__link ${'ipd-summary' === urlSegment ? 'active-left-nav-link' : ''}`}
    >
      <span className={styles.navLinkContent}>
        <HospitalBed size={16} className={styles.navIcon} />
        <span>{t('ipdSummary', title)}</span>
      </span>
    </ConfigurableLink>
  );
}
