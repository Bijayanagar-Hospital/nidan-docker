import React, { useCallback } from 'react';
import useSWR from 'swr';
import { useTranslation } from 'react-i18next';
import { HeaderGlobalAction } from '@carbon/react';
import { Notification as NotificationIcon } from '@carbon/react/icons';
import { openmrsFetch, restBaseUrl, useSession, navigate } from '@openmrs/esm-framework';
import styles from './notification.component.scss';

export default function NotificationNav() {
  const { t } = useTranslation();
  const session = useSession();
  const providerUuid = session?.currentProvider?.uuid || '';

  const { data } = useSWR<any[]>(
    providerUuid ? `${restBaseUrl}/ipd/emergencyMedicationsToAcknowledge?provider_uuid=${providerUuid}` : null,
    (url: string) => openmrsFetch(url).then((res) => res.data),
  );

  const notificationCount = data?.length || 0;

  const viewNotification = useCallback(() => {
    navigate({ to: `${window.getOpenmrsSpaBase()}home/notification` });
  }, []);

  return (
    <HeaderGlobalAction
      aria-label={t('viewNotification', 'Notifications')}
      onClick={viewNotification}
      className={`${styles.navActionButton} ${notificationCount > 0 ? styles.hasNotifications : ''}`}
    >
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '4px' }}>
        <NotificationIcon size={20} />
        {notificationCount > 0 && (
          <span className={styles.notificationBadge}>
            {notificationCount > 9 ? '9+' : notificationCount}
          </span>
        )}
      </div>
    </HeaderGlobalAction>
  );
}
