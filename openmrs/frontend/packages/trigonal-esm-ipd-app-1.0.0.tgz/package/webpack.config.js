const { default: defaultConfig } = require('@openmrs/webpack-config');
// eslint-disable-next-line @typescript-eslint/no-require-imports
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');

module.exports = (env, argv) => {
  const config = defaultConfig(env, argv);

  // Replace ForkTsCheckerWebpackPlugin with a fresh instance that carries the
  // node_modules exclusion from construction — mutation of the existing plugin
  // instance can race with apply() in the child-process dev server.
  //
  // @openmrs/esm-framework dist/index.d.ts references @openmrs/esm-styleguide
  // *source* files that import Carbon components without .d.ts, causing false
  // TS2305/TS2739 errors we have no control over. tsconfig.json paths already
  // redirect src/public → dist/public to break the chain; this is belt-and-
  // suspenders for any remaining node_modules type noise.
  config.plugins = (config.plugins ?? []).filter(
    (p) => p?.constructor?.name !== 'ForkTsCheckerWebpackPlugin',
  );
  config.plugins.push(
    new ForkTsCheckerWebpackPlugin({
      issue: {
        exclude: [
          { severity: 'error', code: 'TS2786' },   // original @openmrs/webpack-config exclusion
          { file: '**/node_modules/**' },            // framework-level type incompatibilities
          { file: '**/e2e/**' },                     // Playwright E2E files aren't part of the app bundle
          { file: 'playwright.config.ts' },          // Playwright config — same reason
        ],
      },
    }),
  );

  return config;
};
