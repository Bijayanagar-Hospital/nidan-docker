module.exports = {
  contextSeparator: '_',
  createOldCatalogs: false,
  defaultNamespace: 'translations',
  defaultValue: '',
  indentation: 2,
  keepRemoved: false,
  keySeparator: '.',
  lexers: {
    hbs: ['HandlebarsLexer'],
    handlebars: ['HandlebarsLexer'],
    htm: ['HTMLLexer'],
    html: ['HTMLLexer'],
    mjs: ['JavascriptLexer'],
    js: ['JavascriptLexer'],
    ts: ['JavascriptLexer'],
    jsx: ['JsxLexer'],
    tsx: ['JsxLexer'],
    default: ['JavascriptLexer'],
  },
  lineEnding: 'auto',
  /**
   * Supported locales — add new locales here when needed.
   *
   * ar: Arabic (RTL)  — uses dir="rtl" set by the O3 primary-navigation shell
   * en: English (LTR) — canonical / fallback
   * es: Spanish (LTR)
   * fr: French  (LTR)
   *
   * Running `yarn extract-translations` will scan all *.component.tsx files and
   * update/create a JSON file for each locale in the translations/ directory.
   * Only en.json entries are auto-populated with default values; all other locales
   * will receive empty strings that translators must fill in.
   */
  locales: ['ar', 'en', 'es', 'fr'],
  namespaceSeparator: ':',
  output: 'translations/$LOCALE.json',
  pluralSeparator: '_',
  sort: true,
  useKeysAsDefaultValue: false,
  verbose: false,
  failOnWarnings: false,
  customValueTemplate: null,
};
